# Hosting Padala for judges

The app is a Next.js **standalone** build with a **SQLite** database in `./db`.
That rules out Vercel (read-only filesystem) — pick any host that gives you a
container + a persistent disk. The repo ships ready-to-deploy configs:

| File | For |
| --- | --- |
| `Dockerfile` | any Docker host (Fly.io, Railway, Render, VPS) |
| `fly.toml` | Fly.io (volume + health check wired) |
| `render.yaml` | Render blueprint |

## 1. Fly.io (recommended — ~10 min)

```bash
# one-time: install flyctl (https://fly.io/docs/flyctl/install), then
fly auth signup                      # or: fly auth login

# in the repo root:
fly launch --copy-config --no-deploy # registers the app from fly.toml
fly volumes create padala_db 1 --region sin   # matches [mounts] in fly.toml
fly secrets set CRON_SECRET=$(openssl rand -hex 24)
fly deploy
fly status                           # wait for "healthy"
open https://padala-demo.fly.dev/api/health   # must say ok:true
```

- `CRON_SECRET` makes `POST /api/cron/settle` and `POST /api/demo/reset`
  require `Authorization: Bearer <secret>`. Without it the endpoints are open —
  on a public host, **always set it**.
- `min_machines_running = 1` keeps one machine warm (first-load MPC derivation
  ≈ 10 s; a suspended machine would add ~30 s). Suspend it after judging with
  `fly machines stop <id>` — billed storage only, no compute.

## 2. Autopilot scheduler (external cron)

The container does **not** run the worker loop; point a free scheduler at the
endpoint instead:

```bash
# cron-job.org (free): every 2 minutes →
curl -X POST https://padala-demo.fly.dev/api/cron/settle \
  -H "Authorization: Bearer <CRON_SECRET>"
```

(Alternative: GitHub Actions cron, or run `bun run worker` as a second Fly
process with the same volume.)

## 3. Render (alternative)

New → **Blueprint** → point at the repo → `render.yaml` is picked up
automatically (web service + 1 GB disk at `/app/db`). Set `CRON_SECRET` in the
dashboard when prompted. Note: the disk needs the paid **starter** plan; on the
free plan the DB resets on each deploy/restart.

## 4. Railway (alternative)

New project → Deploy from repo → Railway detects the Dockerfile. Add a volume
mounted at `/app/db`, then set `CRON_SECRET` in Variables.

## 5. Before judges click (preflight)

```bash
# reset to the pristine 2-invoice story (works remotely too):
curl -X POST https://<host>/api/demo/reset -H "Authorization: Bearer <CRON_SECRET>"
# or from the repo on the host: bun scripts/reset-demo.ts

# sanity: health + smoke test against the public URL
curl https://<host>/api/health
BASE_URL=https://<host> CRON_SECRET=<secret> bun scripts/smoke.ts
```

First dashboard load takes ~10 s (MPC refund derivation over live NEAR RPC) —
normal, not a freeze.

## 6. VPS (docker only)

```bash
docker build -t padala .
docker volume create padala_db
docker run -d --name padala -p 80:3000 \
  -v padala_db:/app/db -e CRON_SECRET=$(openssl rand -hex 24) \
  --restart unless-stopped padala
```
