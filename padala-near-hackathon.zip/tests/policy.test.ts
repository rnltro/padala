/// <reference types="bun-types" />
import { describe, expect, test } from "bun:test";
import { evaluatePolicy, type PolicyRecord } from "../src/lib/policy";

/**
 * Unit tests for the 6-check spending policy engine — the AI Security &
 * Defense layer. Every check is covered at its boundary, because the
 * boundary is exactly where money leaks.
 */

const basePolicy: PolicyRecord = {
  enabled: true,
  perTxLimitUsd: 2500,
  dailyLimitUsd: 7500,
  autoApproveUnderUsd: 1000,
  allowedChains: "base, eth ,arb", // messy CSV on purpose
  allowedRecipients: "",
};

const baseInput = {
  policy: basePolicy,
  amountUsd: 950,
  sourceChain: "base",
  recipient: "maria.padala.near",
  spentTodayUsd: 0,
  treasuryUsdc: 12500,
};

describe("policy engine — happy path", () => {
  test("all 6 checks pass → ALLOWED, WITHIN_LIMITS above auto-approve", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 1450 });
    expect(d.allowed).toBe(true);
    expect(d.mode).toBe("WITHIN_LIMITS");
    expect(d.checks).toHaveLength(6);
    expect(d.checks.every((c) => c.passed)).toBe(true);
    expect(d.blockedReasons).toHaveLength(0);
  });

  test("amount ≤ autoApproveUnderUsd → AUTO_APPROVED", () => {
    expect(evaluatePolicy({ ...baseInput, amountUsd: 1000 }).mode).toBe("AUTO_APPROVED");
    expect(evaluatePolicy({ ...baseInput, amountUsd: 999.99 }).mode).toBe("AUTO_APPROVED");
  });

  test("amount just over auto-approve → WITHIN_LIMITS (human-visible, still allowed)", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 1000.01 });
    expect(d.allowed).toBe(true);
    expect(d.mode).toBe("WITHIN_LIMITS");
  });
});

describe("policy engine — agent_enabled", () => {
  test("paused agent blocks everything, even a $1 payment", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 1, policy: { ...basePolicy, enabled: false } });
    expect(d.allowed).toBe(false);
    expect(d.mode).toBe("BLOCKED");
    expect(d.blockedReasons[0]).toContain("Agent wallet enabled");
  });
});

describe("policy engine — per_tx_limit", () => {
  test("amount exactly at the limit passes (boundary inclusive)", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 2500 });
    expect(d.allowed).toBe(true);
  });

  test("one cent over the limit blocks", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 2500.01 });
    expect(d.allowed).toBe(false);
    expect(d.blockedReasons[0]).toContain("Per-transaction limit");
    expect(d.blockedReasons[0]).toContain("$2,500.01");
  });
});

describe("policy engine — daily_cap", () => {
  test("spentToday + amount exactly at the cap passes", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 500, spentTodayUsd: 7000 });
    expect(d.allowed).toBe(true);
  });

  test("spentToday + amount over the cap blocks", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 500.01, spentTodayUsd: 7000 });
    expect(d.allowed).toBe(false);
    expect(d.blockedReasons.some((r) => r.includes("Daily spend cap"))).toBe(true);
  });
});

describe("policy engine — chain_allowlist", () => {
  test("messy CSV with spaces + case still matches (parse is case-insensitive)", () => {
    const d = evaluatePolicy({ ...baseInput, sourceChain: "ARB" });
    expect(d.allowed).toBe(true);
  });

  test("chain not on the allowlist blocks", () => {
    const d = evaluatePolicy({ ...baseInput, sourceChain: "solana" });
    expect(d.allowed).toBe(false);
    expect(d.blockedReasons[0]).toContain("not on the allowlist");
  });
});

describe("policy engine — recipient_allowlist", () => {
  test("empty allowlist = any recipient allowed", () => {
    const d = evaluatePolicy({ ...baseInput, recipient: "stranger.padala.near" });
    expect(d.allowed).toBe(true);
  });

  test("configured allowlist blocks unknown payees", () => {
    const policy = { ...basePolicy, allowedRecipients: "Maria.Padala.Near, ben.padala.near" };
    const ok = evaluatePolicy({ ...baseInput, recipient: "maria.padala.near", policy });
    const blocked = evaluatePolicy({ ...baseInput, recipient: "stranger.padala.near", policy });
    expect(ok.allowed).toBe(true);
    expect(blocked.allowed).toBe(false);
    expect(blocked.blockedReasons[0]).toContain("not an approved payee");
  });
});

describe("policy engine — treasury_balance", () => {
  test("treasury short of the amount blocks", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 500, treasuryUsdc: 499.99 });
    expect(d.allowed).toBe(false);
    expect(d.blockedReasons[0]).toContain("Treasury sufficient");
  });

  test("treasury exactly equal passes", () => {
    const d = evaluatePolicy({ ...baseInput, amountUsd: 500, treasuryUsdc: 500 });
    expect(d.allowed).toBe(true);
  });
});

describe("policy engine — multiple failures", () => {
  test("collects every failed check, not just the first", () => {
    const d = evaluatePolicy({
      ...baseInput,
      amountUsd: 9000,
      sourceChain: "solana",
      treasuryUsdc: 100,
      policy: { ...basePolicy, enabled: false },
    });
    expect(d.allowed).toBe(false);
    // agent_enabled + per_tx + daily_cap + chain + treasury = 5 failures
    expect(d.blockedReasons).toHaveLength(5);
  });
});
