/// <reference types="bun-types" />
import { describe, expect, test } from "bun:test";
import {
  MAX_PAYROLL_LINES,
  parsePayrollText,
  policyPreFlight,
  validateInvoiceLine,
  validateSingleInvoiceFields,
} from "../src/lib/invoicing";

/**
 * Unit tests for the shared invoice validation + batch-payroll helpers —
 * the same code path used by POST /api/invoices and POST /api/payroll-runs.
 */

describe("validateInvoiceLine", () => {
  test("accepts a good line and normalizes the amount to cents", () => {
    const r = validateInvoiceLine({ clientName: "  Acme  ", amountUsd: 1450, freelancerAccount: "maria.padala.near" }, 1);
    expect(r.ok).toBe(true);
    if (r.ok) expect(r.line.amountUsd).toBe(1450);
  });

  test("rejects missing client / account / amount", () => {
    expect(validateInvoiceLine({ clientName: "", amountUsd: 10, freelancerAccount: "a.near" }, 1).ok).toBe(false);
    expect(validateInvoiceLine({ clientName: "A", amountUsd: 10, freelancerAccount: "" }, 1).ok).toBe(false);
    expect(validateInvoiceLine({ clientName: "A", amountUsd: 0, freelancerAccount: "a.near" }, 1).ok).toBe(false);
    expect(validateInvoiceLine({ clientName: "A", amountUsd: -5, freelancerAccount: "a.near" }, 1).ok).toBe(false);
  });

  test("rejects non-NEAR-looking accounts (the classic typo guard)", () => {
    const r = validateInvoiceLine({ clientName: "A", amountUsd: 10, freelancerAccount: "maria at padala" }, 1);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.error).toContain("must look like a NEAR account");
  });

  test("accepts testnet + 64-hex implicit accounts", () => {
    expect(validateInvoiceLine({ clientName: "A", amountUsd: 1, freelancerAccount: "ben.testnet" }, 1).ok).toBe(true);
    expect(
      validateInvoiceLine(
        { clientName: "A", amountUsd: 1, freelancerAccount: "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef" },
        1,
      ).ok,
    ).toBe(true);
  });

  test("rejects amounts over the hard cap", () => {
    expect(validateInvoiceLine({ clientName: "A", amountUsd: 2_000_000, freelancerAccount: "a.near" }, 1).ok).toBe(false);
  });
});

describe("validateSingleInvoiceFields", () => {
  test("same rules as batch lines — description required here", () => {
    expect(validateSingleInvoiceFields({ clientName: "A", description: "", amountUsd: 10, freelancerAccount: "a.near" })).toContain(
      "description",
    );
    expect(validateSingleInvoiceFields({ clientName: "A", description: "work", amountUsd: 10, freelancerAccount: "a.near" })).toBeNull();
  });
});

describe("policyPreFlight", () => {
  const policy = { perTxLimitUsd: 2500, dailyLimitUsd: 7500 };

  test("no warnings when everything fits", () => {
    expect(policyPreFlight([{ amountUsd: 1450 }, { amountUsd: 900 }], policy)).toHaveLength(0);
  });

  test("warns per line over the per-tx limit", () => {
    const w = policyPreFlight([{ amountUsd: 3000 }, { amountUsd: 100 }], policy);
    expect(w).toHaveLength(1);
    expect(w[0]).toContain("per-tx limit");
  });

  test("warns when the run total exceeds the daily cap", () => {
    const w = policyPreFlight([{ amountUsd: 4000 }, { amountUsd: 4000 }], policy);
    expect(w.some((x) => x.includes("daily cap"))).toBe(true);
  });

  test("warns twice when a line breaks both rules", () => {
    const w = policyPreFlight([{ amountUsd: 9000 }], policy);
    expect(w).toHaveLength(2);
  });
});

describe("parsePayrollText", () => {
  test("parses the README example (commas)", () => {
    const { lines, errors } = parsePayrollText("Acme Studio, 1450, maria.padala.near\nBen Santos, 1200, ben.padala.near");
    expect(errors).toHaveLength(0);
    expect(lines).toHaveLength(2);
    expect(lines[0]).toEqual({ clientName: "Acme Studio", amountUsd: 1450, freelancerAccount: "maria.padala.near" });
  });

  test("parses spreadsheet tab-paste", () => {
    const { lines, errors } = parsePayrollText("Ana Reyes\t850\tana.padala.near");
    expect(errors).toHaveLength(0);
    expect(lines[0].clientName).toBe("Ana Reyes");
  });

  test("skips empty lines and #comments", () => {
    const { lines } = parsePayrollText("# November batch\n\nAcme, 100, a.near\n\n");
    expect(lines).toHaveLength(1);
  });

  test("reports per-line errors without aborting the parse", () => {
    const { lines, errors } = parsePayrollText("Good, 100, a.near\nBad line\nAnother, notanumber, b.near");
    expect(lines).toHaveLength(1);
    expect(errors).toHaveLength(2);
    expect(errors[0].line).toBe(2);
    expect(errors[1].error).toContain("not a number");
  });

  test("const MAX_PAYROLL_LINES stays at the documented 50", () => {
    expect(MAX_PAYROLL_LINES).toBe(50);
  });
});
