import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Padala — Cross-chain payroll on NEAR",
  description:
    "Freelancers invoice in USD, employers pay USDC from any chain via NEAR Intents, freelancers receive native USDC on NEAR — guarded by a policy-enforced agent wallet with a full audit trail. Built for the NEAR HACKATHON (Real-World Money + AI Security & Defense tracks).",
  keywords: ["NEAR", "NEAR Intents", "1Click", "stablecoin payroll", "cross-chain", "AI agent", "hackathon"],
  authors: [{ name: "Padala — NEAR HACKATHON submission" }],
  openGraph: {
    title: "Padala — Cross-chain payroll on NEAR",
    description: "Any-chain USDC in, native USDC on NEAR out. Policy-gated agent treasury with an append-only audit trail.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
