import { db } from "@/lib/db";
import { ensureSeed } from "@/lib/treasury";
import { Landmark } from "lucide-react";
import { PaymentClient } from "@/components/padala/payment-client";
import type { Invoice } from "@/components/padala/types";

/**
 * Public, no-login payment page for clients.
 * Freelancer shares /pay/INV-1002 → client opens it, pays USDC from any chain.
 */
export default async function PayPage({
  params,
}: {
  params: Promise<{ reference: string }>;
}) {
  const { reference } = await params;
  await ensureSeed();

  const row = await db.invoice.findUnique({
    where: { reference },
    include: { payments: { orderBy: { createdAt: "desc" } } },
  });

  if (!row) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-background px-4">
        <div className="w-full max-w-md rounded-xl border border-dashed p-10 text-center">
          <Landmark className="mx-auto h-10 w-10 opacity-40" />
          <h1 className="mt-4 text-lg font-semibold">Invoice not found</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            No invoice with reference <span className="font-mono">{reference}</span>. Ask the
            freelancer to re-share the payment link.
          </p>
        </div>
      </main>
    );
  }

  const invoice: Invoice = {
    id: row.id,
    reference: row.reference,
    clientName: row.clientName,
    description: row.description,
    amountUsd: row.amountUsd,
    status: row.status,
    dueDate: row.dueDate.toISOString(),
    freelancerAccount: row.freelancerAccount,
    refundAddress: row.refundAddress,
    refundPath: row.refundPath,
    autoSettle: row.autoSettle,
    maxFeeBps: row.maxFeeBps,
    autopilotChain: row.autopilotChain,
    payrollRunLabel: row.payrollRunLabel,
    createdAt: row.createdAt.toISOString(),
    paidAt: row.paidAt ? row.paidAt.toISOString() : null,
    payments: row.payments.map((p) => ({
      id: p.id,
      invoiceId: p.invoiceId,
      sourceChain: p.sourceChain,
      sourceAsset: p.sourceAsset,
      amountInUsd: p.amountInUsd,
      amountOut: p.amountOut,
      amountOutUsd: p.amountOutUsd,
      depositAddress: p.depositAddress,
      quoteDeadline: p.quoteDeadline ? p.quoteDeadline.toISOString() : null,
      timeEstimate: p.timeEstimate,
      status: p.status,
      simulated: p.simulated,
      createdAt: p.createdAt.toISOString(),
      settledAt: p.settledAt ? p.settledAt.toISOString() : null,
    })),
  };

  return <PaymentClient invoice={invoice} />;
}
