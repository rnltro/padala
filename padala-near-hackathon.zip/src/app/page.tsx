import { Dashboard } from "@/components/padala/dashboard";

export default function Home() {
  return <Dashboard />;
}
