import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";
import { ensurePolicy } from "@/lib/treasury";

const CHAIN_IDS = new Set(["base", "eth", "arb", "sol"]);

export async function GET() {
  const policy = await ensurePolicy();
  return NextResponse.json({ policy });
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const num = (v: unknown, min: number, max: number) => {
      const n = Number(v);
      return Number.isFinite(n) && n >= min && n <= max ? Math.round(n * 100) / 100 : null;
    };

    const perTxLimitUsd = num(body.perTxLimitUsd, 1, 1_000_000);
    const dailyLimitUsd = num(body.dailyLimitUsd, 1, 10_000_000);
    const autoApproveUnderUsd = num(body.autoApproveUnderUsd, 0, 100_000);

    const allowedChains = Array.isArray(body.allowedChains)
      ? body.allowedChains.filter((c: unknown) => typeof c === "string" && CHAIN_IDS.has(c))
      : null;
    if (allowedChains !== null && allowedChains.length === 0) {
      return NextResponse.json({ error: "At least one chain must be allowed" }, { status: 400 });
    }
    if (perTxLimitUsd === null || dailyLimitUsd === null || autoApproveUnderUsd === null) {
      return NextResponse.json({ error: "Invalid limit values" }, { status: 400 });
    }
    const allowedRecipients = typeof body.allowedRecipients === "string"
      ? body.allowedRecipients
          .split(",")
          .map((s: string) => s.trim())
          .filter(Boolean)
          .join(",")
      : "";

    const before = await ensurePolicy();
    const policy = await db.policy.update({
      where: { id: "default" },
      data: {
        enabled: typeof body.enabled === "boolean" ? body.enabled : before.enabled,
        perTxLimitUsd,
        dailyLimitUsd,
        autoApproveUnderUsd,
        allowedChains: allowedChains ? allowedChains.join(",") : before.allowedChains,
        allowedRecipients,
      },
    });

    await recordAudit(db, {
      type: "POLICY_UPDATED",
      actor: ACTORS.employer,
      summary: `Agent policy updated — $${policy.perTxLimitUsd.toLocaleString()}/tx, $${policy.dailyLimitUsd.toLocaleString()}/day, auto-approve under $${policy.autoApproveUnderUsd.toLocaleString()}, chains: ${policy.allowedChains}${policy.enabled ? "" : " (AGENT PAUSED)"}`,
      detail: {
        before: { perTxLimitUsd: before.perTxLimitUsd, dailyLimitUsd: before.dailyLimitUsd, enabled: before.enabled },
        after: {
          perTxLimitUsd: policy.perTxLimitUsd,
          dailyLimitUsd: policy.dailyLimitUsd,
          enabled: policy.enabled,
          allowedChains: policy.allowedChains,
          allowedRecipients: policy.allowedRecipients,
        },
      },
    });

    return NextResponse.json({ policy });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Policy update failed" },
      { status: 500 },
    );
  }
}
