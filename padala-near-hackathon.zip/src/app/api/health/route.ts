import { NextResponse } from "next/server";

/**
 * Self-diagnosis endpoint — runs even when everything else is broken.
 * The Treasury error card fetches this and shows the exact cause + fix,
 * so a cold clone that skipped a setup step tells the user what to do
 * instead of failing silently. NO static Prisma import here: the db client
 * is imported dynamically inside try/catch so init failures are reported,
 * not thrown.
 *
 * Also probes the two external APIs the app depends on (NEAR RPC for the
 * MPC root key, 1Click for quotes) — reachability failures there are the
 * #1 cause of "refund address fallback" + "pay fails" on locked-down
 * machines (firewall/VPN/antivirus), and this names them explicitly.
 */
export const dynamic = "force-dynamic";

type HealthReport = {
  ok: boolean;
  /** Seconds this server process has been up — if it keeps growing after a
   *  restart, an older process still owns the port (classic Windows trap). */
  uptimeSec: number;
  databaseUrlSet: boolean;
  databaseOk: boolean;
  /** Prisma error code if any (P1012 / P2021 / P1003 …). */
  code: string | null;
  /** Raw error message from the db layer. */
  error: string | null;
  /** Plain-language diagnosis. */
  diagnosis: string;
  /** Exact fix commands (Windows PowerShell + mac/linux). */
  fix: { windows: string[]; unix: string[] } | null;
  /** Reachability of the two external APIs. `ok` stays true when the app
   *  itself is healthy — these are informational for diagnosis. */
  network: {
    nearRpc: { ok: boolean; ms: number | null; error: string | null };
    oneClick: { ok: boolean; ms: number | null; error: string | null };
  };
};

function diagnose(code: string | null, message: string, dbUrlSet: boolean) {
  if (!dbUrlSet) {
    return {
      diagnosis:
        "No DATABASE_URL found — the .env file is missing (or the server was started before it existed).",
      fix: {
        windows: ["# stop the dev server (Ctrl+C), then:", "bun run setup", "# restart: bun run dev"],
        unix: ["bun run setup", "# restart: bun run dev"],
      },
    };
  }
  if (code === "P2021" || message.includes("does not exist in the current database")) {
    return {
      diagnosis:
        "The .env is fine but the database has no tables — `bun run setup` (or `bun run db:push`) was skipped or failed.",
      fix: {
        windows: ["# stop the dev server (Ctrl+C), then:", "bun run setup", "# restart: bun run dev"],
        unix: ["bun run setup", "# restart: bun run dev"],
      },
    };
  }
  if (message.includes("did not initialize yet") || /prisma generate/i.test(message)) {
    return {
      diagnosis: "The Prisma Client was never generated (bun install ran without its postinstall step).",
      fix: {
        windows: ["bun install", "bun run setup", "# restart: bun run dev"],
        unix: ["bun install", "bun run setup", "# restart: bun run dev"],
      },
    };
  }
  if (code === "P1003" || message.includes("cannot open") || message.includes("unable to open")) {
    return {
      diagnosis: "The SQLite database file could not be opened/created — recreate it with `bun run setup`.",
      fix: {
        windows: ["# stop the dev server (Ctrl+C), then:", "bun run setup", "# restart: bun run dev"],
        unix: ["bun run setup", "# restart: bun run dev"],
      },
    };
  }
  return {
    diagnosis: "The database layer returned an unexpected error — paste the message below when asking for help.",
    fix: null,
  };
}

/** Any HTTP response counts as reachable — only DNS/timeout/refused fail. */
async function probe(
  url: string,
  init: RequestInit,
): Promise<{ ok: boolean; ms: number | null; error: string | null }> {
  const t0 = Date.now();
  try {
    await fetch(url, { ...init, signal: AbortSignal.timeout(6_000) });
    return { ok: true, ms: Date.now() - t0, error: null };
  } catch (err) {
    return {
      ok: false,
      ms: null,
      error: err instanceof Error ? err.message.slice(0, 160) : String(err).slice(0, 160),
    };
  }
}

function networkDiagnosis(nearRpc: { ok: boolean; error: string | null }, oneClick: { ok: boolean; error: string | null }) {
  const down: string[] = [];
  if (!nearRpc.ok) down.push("NEAR RPC (rpc.mainnet.near.org — MPC root key for refund derivation)");
  if (!oneClick.ok) down.push("the 1Click API (1click.chaindefuser.com — settlement quotes)");
  if (down.length === 0) return null;
  return {
    diagnosis:
      `The app is healthy, but ${down.join(" and ")} ${down.length === 1 ? "is" : "are"} unreachable from this machine. ` +
      "Invoices still create (refund address falls back to the demo wallet) but real settlement quotes fail.",
    fix: {
      windows: [
        "# allow outbound HTTPS for bun/node in your firewall/antivirus, then test:",
        'curl https://rpc.mainnet.near.org -X POST -H "Content-Type: application/json" -d "{\\"jsonrpc\\":\\"2.0\\",\\"id\\":\\"t\\",\\"method\\":\\"status\\",\\"params\\":[]}"',
        "# optional — derive refund addresses fully offline (no NEAR RPC needed):",
        "#   add MPC_PUBLIC_KEY=secp256k1:... to .env (live root key: scripts/verify-derivation.ts)",
      ],
      unix: [
        "# check outbound HTTPS (VPN/proxy can block it), then test:",
        'curl https://rpc.mainnet.near.org -X POST -H "Content-Type: application/json" -d \'{"jsonrpc":"2.0","id":"t","method":"status","params":[]}\'',
        "# optional — derive refund addresses fully offline (no NEAR RPC needed):",
        "#   add MPC_PUBLIC_KEY=secp256k1:... to .env (live root key: scripts/verify-derivation.ts)",
      ],
    },
  };
}

export async function GET() {
  const dbUrlSet = Boolean(process.env.DATABASE_URL);
  let databaseOk = false;
  let code: string | null = null;
  let error: string | null = null;

  // DB + both network probes run concurrently — a cold RPC should not
  // multiply the wait. Probes are capped at 6 s each.
  const [dbResult, nearRpc, oneClick] = await Promise.all([
    (async () => {
      try {
        const { db } = await import("@/lib/db");
        await db.auditEvent.count(); // cheapest possible query
        return { ok: true, code: null as string | null, error: null as string | null };
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        const m = message.match(/P\d{4}/);
        return { ok: false, code: m ? m[0] : null, error: message };
      }
    })(),
    probe(process.env.NEAR_RPC_URL || "https://rpc.mainnet.near.org", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: "padala-health", method: "status", params: [] }),
    }),
    probe(
      `${(process.env.ONECLICK_URL || "https://1click.chaindefuser.com/v0").replace(/\/$/, "")}/status?quoteId=health-probe`,
      { method: "GET" },
    ),
  ]);

  databaseOk = dbResult.ok;
  code = dbResult.code;
  error = dbResult.error;

  const base: HealthReport = {
    ok: databaseOk,
    uptimeSec: Math.round(process.uptime()),
    databaseUrlSet: dbUrlSet,
    databaseOk,
    code,
    error: error ? error.slice(0, 500) : null,
    diagnosis: databaseOk ? "All good — database reachable and seeded data queryable." : "",
    fix: null,
    network: { nearRpc, oneClick },
  };

  if (!databaseOk) {
    const d = diagnose(code, error ?? "", dbUrlSet);
    base.diagnosis = d.diagnosis;
    base.fix = d.fix;
  } else {
    const net = networkDiagnosis(nearRpc, oneClick);
    if (net) {
      base.diagnosis = net.diagnosis;
      base.fix = net.fix;
    }
  }

  return NextResponse.json(base, { status: 200 });
}
