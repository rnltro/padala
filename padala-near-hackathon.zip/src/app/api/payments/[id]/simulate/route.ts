import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";

/**
 * DEMO-ONLY endpoint: mark a pending payment as settled without waiting for a
 * real on-chain deposit. Exists so judges can see the full happy path in a
 * demo video. Every simulated settlement is clearly labeled in the payment
 * record and the audit trail. In production, settlement comes exclusively
 * from the 1Click status poller.
 */
export async function POST(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const payment = await db.payment.findUnique({ where: { id }, include: { invoice: true } });
    if (!payment) return NextResponse.json({ error: "Payment not found" }, { status: 404 });
    if (payment.status === "SUCCESS") {
      return NextResponse.json({ payment });
    }

    const settledAt = new Date();
    const [updated] = await Promise.all([
      db.payment.update({
        where: { id },
        data: { status: "SUCCESS", simulated: true, settledAt },
      }),
      db.invoice.update({
        where: { id: payment.invoiceId },
        data: { status: "PAID", paidAt: settledAt },
      }),
    ]);

    await recordAudit(db, {
      type: "PAYMENT_SETTLED_SIMULATED",
      actor: ACTORS.system,
      invoiceRef: payment.invoice.reference,
      summary: `Settlement confirmed (demo) — ${payment.amountOutUsd?.toFixed(2) ?? payment.amountInUsd.toFixed(2)} USDC credited to ${payment.invoice.freelancerAccount} on NEAR`,
      detail: {
        simulated: true,
        note: "Demo settlement for judging; production settles via 1Click status polling",
        depositAddress: payment.depositAddress,
      },
    });

    return NextResponse.json({ payment: updated });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Simulate failed" },
      { status: 500 },
    );
  }
}
