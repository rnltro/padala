import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";
import { getDepositStatus } from "@/lib/intents";

const SETTLED_STATUSES = new Set(["SUCCESS", "REFUNDED", "FAILED"]);

/**
 * Poll the live 1Click status for a payment's deposit address.
 * On SUCCESS: mark payment + invoice settled and write the audit entry.
 * (REFUNDED/FAILED are recorded but not marked paid — funds went back.)
 */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const payment = await db.payment.findUnique({
      where: { id },
      include: { invoice: true },
    });
    if (!payment) return NextResponse.json({ error: "Payment not found" }, { status: 404 });

    if (SETTLED_STATUSES.has(payment.status)) {
      return NextResponse.json({ payment });
    }

    const result = await getDepositStatus(payment.depositAddress);
    if (!result.ok) {
      return NextResponse.json({ payment, pollError: result.error });
    }

    if (result.status === payment.status) {
      return NextResponse.json({ payment });
    }

    if (result.status === "SUCCESS") {
      const settledAt = new Date();
      const [updated] = await Promise.all([
        db.payment.update({
          where: { id },
          data: { status: "SUCCESS", settledAt },
        }),
        db.invoice.update({
          where: { id: payment.invoiceId },
          data: { status: "PAID", paidAt: settledAt },
        }),
      ]);
      await recordAudit(db, {
        type: "PAYMENT_SETTLED",
        actor: ACTORS.agent,
        invoiceRef: payment.invoice.reference,
        summary: `Settlement confirmed — ${payment.amountOutUsd?.toFixed(2) ?? payment.amountInUsd.toFixed(2)} USDC credited to ${payment.invoice.freelancerAccount} on NEAR`,
        detail: { paymentId: id, depositAddress: payment.depositAddress, live: true },
      });
      return NextResponse.json({ payment: updated });
    }

    const updated = await db.payment.update({
      where: { id },
      data: { status: result.status },
    });
    return NextResponse.json({ payment: updated });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Status check failed" },
      { status: 500 },
    );
  }
}
