import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ensureSeed } from "@/lib/treasury";

const WIRE_COST_USD = 45; // typical SWIFT wire fee, $25–50
const WIRE_DAYS = "3–5 business days";

/**
 * Impact analytics for the demo: what actually settled, how fast, at what cost,
 * and what the same volume would have cost over SWIFT wires.
 */
export async function GET() {
  await ensureSeed();

  const settled = await db.payment.findMany({
    where: { status: "SUCCESS" },
    select: {
      amountInUsd: true,
      amountOutUsd: true,
      createdAt: true,
      settledAt: true,
      simulated: true,
    },
  });

  const invoicesPaid = await db.invoice.count({ where: { status: "PAID" } });
  const volumeUsd = settled.reduce(
    (sum, p) => sum + (p.amountOutUsd ?? p.amountInUsd),
    0,
  );

  // Settle time = quote creation → SUCCESS observed.
  const settleSecs = settled
    .filter((p) => p.settledAt)
    .map((p) => (p.settledAt!.getTime() - p.createdAt.getTime()) / 1000)
    .filter((s) => s >= 0);
  const avgSettleSec =
    settleSecs.length > 0
      ? Math.round(settleSecs.reduce((a, b) => a + b, 0) / settleSecs.length)
      : null;

  // All-in cost from real quote math: (in − out) / in, in basis points.
  const costBps = settled
    .filter((p) => p.amountOutUsd && p.amountInUsd > 0)
    .map((p) => ((p.amountInUsd - p.amountOutUsd!) / p.amountInUsd) * 10_000);
  const avgCostBps =
    costBps.length > 0
      ? Math.round((costBps.reduce((a, b) => a + b, 0) / costBps.length) * 10) / 10
      : null;
  const totalCostUsd = settled.reduce(
    (sum, p) => sum + Math.max(0, p.amountInUsd - (p.amountOutUsd ?? p.amountInUsd)),
    0,
  );

  return NextResponse.json({
    paymentsSettled: settled.length,
    liveSettled: settled.filter((p) => !p.simulated).length,
    invoicesPaid,
    volumeUsd: Math.round(volumeUsd * 100) / 100,
    avgSettleSec,
    avgCostBps,
    wire: { costUsd: WIRE_COST_USD, days: WIRE_DAYS },
    savedVsWireUsd: Math.round((settled.length * WIRE_COST_USD - totalCostUsd) * 100) / 100,
  });
}
