import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  AGENT_ACCOUNT,
  AGENT_DESCRIPTION,
  ensurePolicy,
  ensureSeed,
  settledTodayUsd,
  treasuryBalanceUsdc,
} from "@/lib/treasury";

export async function GET() {
  await ensureSeed();
  const [policy, balance, spentToday] = await Promise.all([
    ensurePolicy(),
    treasuryBalanceUsdc(),
    settledTodayUsd(),
  ]);

  const pendingCount = await db.payment.count({ where: { status: { not: "SUCCESS" } } });
  const paidCount = await db.invoice.count({ where: { status: "PAID" } });

  return NextResponse.json({
    agent: {
      account: AGENT_ACCOUNT,
      description: AGENT_DESCRIPTION,
      network: "NEAR mainnet (demo data)",
    },
    balanceUsdc: balance,
    spentTodayUsd: spentToday,
    remainingTodayUsd: Math.max(0, policy.dailyLimitUsd - spentToday),
    dailyLimitUsd: policy.dailyLimitUsd,
    perTxLimitUsd: policy.perTxLimitUsd,
    policyEnabled: policy.enabled,
    pendingPayments: pendingCount,
    invoicesPaid: paidCount,
  });
}
