import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";
import { deriveRefundAddress } from "@/lib/chainsignatures";
import { ensurePolicy } from "@/lib/treasury";
import {
  MAX_PAYROLL_LINES,
  policyPreFlight,
  validateInvoiceLine,
  type InvoiceLine,
} from "@/lib/invoicing";

/**
 * Batch payroll — one paste, many invoices, one transaction.
 *
 * POST /api/payroll-runs
 *   { label, description?, scheduledFor?, autoSettle?, maxFeeBps?,
 *     lines: [{ clientName, amountUsd, freelancerAccount }, ...] }  (≤50)
 *
 * Guarantees (all-or-nothing):
 *   - every line is validated BEFORE anything is written; one bad line
 *     returns 400 with per-line errors and creates nothing,
 *   - refund addresses derive in parallel waves BEFORE any row is written,
 *   - the run + every invoice commit in ONE Prisma transaction — a failure
 *     on line 9 never leaves a half-created payroll,
 *   - policy pre-flight warns when the run exceeds the daily cap or a line
 *     exceeds the per-tx limit (warnings, not blocks — the spending policy
 *     still gates every settlement individually at pay time),
 *   - exactly ONE summary audit event (PAYROLL_RUN_CREATED) carries the
 *     invoice references and the policy snapshot.
 *
 * GET /api/payroll-runs — recent runs for the dashboard.
 */
export const dynamic = "force-dynamic";

/** Derive refund addresses in parallel waves so a 50-line run doesn't burst the RPC. */
async function deriveRefundsInWaves(lines: InvoiceLine[], refs: string[], wave = 8) {
  const results: ({ address: string; path: string } | null)[] = new Array(lines.length).fill(null);
  for (let start = 0; start < lines.length; start += wave) {
    const slice = lines.slice(start, start + wave).map((l, i) =>
      deriveRefundAddress(refs[start + i]).then((r) => {
        results[start + i] = r.ok ? { address: r.address, path: r.path } : null;
      }),
    );
    await Promise.all(slice);
  }
  return results;
}

export async function GET() {
  const runs = await db.payrollRun.findMany({ orderBy: { createdAt: "desc" }, take: 50 });
  return NextResponse.json({ runs });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const label = String(body.label ?? "").trim();
    const description = String(body.description ?? "").trim();
    const scheduledFor = body.scheduledFor ? new Date(body.scheduledFor) : null;
    const autoSettle = body.autoSettle === true;
    let maxFeeBps = Math.round(Number(body.maxFeeBps ?? 100));
    if (!Number.isFinite(maxFeeBps) || maxFeeBps < 1) maxFeeBps = 1;
    if (maxFeeBps > 1000) maxFeeBps = 1000;

    if (!label) {
      return NextResponse.json({ error: "label is required (e.g. \"November contractor payroll\")" }, { status: 400 });
    }
    if (label.length > 120) {
      return NextResponse.json({ error: "label is too long (max 120 chars)" }, { status: 400 });
    }
    if (scheduledFor && Number.isNaN(scheduledFor.getTime())) {
      return NextResponse.json({ error: "scheduledFor must be a valid date" }, { status: 400 });
    }
    if (!Array.isArray(body.lines) || body.lines.length === 0) {
      return NextResponse.json({ error: "lines must be a non-empty array" }, { status: 400 });
    }
    if (body.lines.length > MAX_PAYROLL_LINES) {
      return NextResponse.json({ error: `too many lines — up to ${MAX_PAYROLL_LINES} per run` }, { status: 400 });
    }

    // ---- 1. Validate EVERY line before writing anything (all-or-nothing). ----
    const lineErrors: { line: number; error: string }[] = [];
    const lines: InvoiceLine[] = [];
    body.lines.forEach((raw: unknown, i: number) => {
      const res = validateInvoiceLine(raw, i + 1);
      if (res.ok) lines.push(res.line);
      else lineErrors.push({ line: i + 1, error: res.error });
    });
    if (lineErrors.length > 0) {
      return NextResponse.json(
        {
          error: `${lineErrors.length} of ${body.lines.length} lines invalid — nothing was created`,
          lineErrors,
        },
        { status: 400 },
      );
    }

    // ---- 2. Policy pre-flight (warnings, not blocks). ----
    const policy = await ensurePolicy();
    const warnings = policyPreFlight(lines, policy);

    // ---- 3. References up-front so refund derivations know their paths. ----
    const count = await db.invoice.count();
    const refs = lines.map((_, i) => `INV-${1001 + count + i}`);

    // ---- 4. Refund addresses in parallel waves BEFORE any row is written. ----
    const refunds = await deriveRefundsInWaves(lines, refs);

    const totalUsd = Math.round(lines.reduce((s, l) => s + l.amountUsd, 0) * 100) / 100;

    // ---- 5. One transaction: the run + every invoice, or nothing. ----
    const created = await db.$transaction(async (tx) => {
      const run = await tx.payrollRun.create({
        data: {
          label,
          description,
          scheduledFor,
          autoSettle,
          maxFeeBps,
          lineCount: lines.length,
          totalUsd,
          invoiceRefs: JSON.stringify(refs),
          warnings: JSON.stringify(warnings),
        },
      });

      const invoices: Awaited<ReturnType<typeof tx.invoice.create>>[] = [];
      for (let i = 0; i < lines.length; i += 1) {
        const l = lines[i];
        const r = refunds[i];
        invoices.push(
          await tx.invoice.create({
            data: {
              reference: refs[i],
              clientName: l.clientName,
              description: description || `Batch payroll — ${label}`,
              amountUsd: l.amountUsd,
              dueDate: scheduledFor ?? new Date(Date.now() + 14 * 24 * 60 * 60 * 1000),
              freelancerAccount: l.freelancerAccount,
              refundAddress: r?.address ?? null,
              refundPath: r ? `refund-${refs[i]}` : null,
              autoSettle,
              maxFeeBps,
              payrollRunLabel: label,
            },
          }),
        );
      }
      return { run, invoices };
    });

    // ---- 6. One summary audit event for the whole run. ----
    await recordAudit(db, {
      type: "PAYROLL_RUN_CREATED",
      actor: ACTORS.employer,
      summary: `Payroll run "${label}" created — ${lines.length} invoices, $${totalUsd.toFixed(2)} total (${created.invoices.map((i) => i.reference).join(", ")})`,
      detail: {
        runId: created.run.id,
        label,
        invoiceRefs: refs,
        totalUsd,
        autoSettle,
        maxFeeBps,
        warnings,
        policySnapshot: {
          perTxLimitUsd: policy.perTxLimitUsd,
          dailyLimitUsd: policy.dailyLimitUsd,
          autoApproveUnderUsd: policy.autoApproveUnderUsd,
          allowedChains: policy.allowedChains,
        },
      },
    });

    // Refund-derivation audit events (same shape as the single-invoice route).
    for (let i = 0; i < lines.length; i += 1) {
      const r = refunds[i];
      if (!r) continue;
      await recordAudit(db, {
        type: "REFUND_ADDRESS_DERIVED",
        actor: ACTORS.system,
        invoiceRef: refs[i],
        summary: `Refund address ${r.address} derived from NEAR MPC root key — path "refund-${refs[i]}" (batch "${label}")`,
        detail: { derivationPath: `refund-${refs[i]}`, batchRun: label },
      });
    }

    return NextResponse.json(
      { run: created.run, invoices: created.invoices, warnings },
      { status: 201 },
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "Failed to create payroll run";
    const conflict = message.includes("Unique constraint");
    return NextResponse.json(
      { error: conflict ? "Reference collision (concurrent creation) — retry the paste." : message },
      { status: conflict ? 409 : 500 },
    );
  }
}
