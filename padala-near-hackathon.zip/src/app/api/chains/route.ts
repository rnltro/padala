import { NextResponse } from "next/server";
import { SOURCE_CHAINS } from "@/lib/intents";

export async function GET() {
  return NextResponse.json({
    chains: SOURCE_CHAINS.map(({ id, label, note }) => ({ id, label, note })),
    destination: {
      chain: "NEAR",
      asset: "USDC (native, nep141)",
      note: "Credited to the freelancer's NEAR Intents balance",
    },
  });
}
