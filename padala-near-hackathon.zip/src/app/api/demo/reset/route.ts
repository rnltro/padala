import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { resetDemoData } from "@/lib/reset";

/**
 * POST /api/demo/reset — wipe demo data and re-seed to the pristine state.
 *
 * For hosted-demo hygiene: after judges have poked the dashboard, one call
 * restores the seeded story (INV-1001 PAID, INV-1002 awaiting) with fresh
 * MPC refund addresses.
 *
 * Auth: set DEMO_RESET_SECRET (or CRON_SECRET) to require
 * `Authorization: Bearer <secret>`. Unset = open (dev mode) — same contract
 * as POST /api/cron/settle.
 */
export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  const secret = process.env.DEMO_RESET_SECRET ?? process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers.get("authorization");
    if (auth !== `Bearer ${secret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  try {
    const { cleared } = await resetDemoData(db);
    return NextResponse.json({
      ok: true,
      cleared,
      seeded: { invoices: ["INV-1001 (PAID)", "INV-1002 (awaiting payment)"] },
    });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Reset failed" },
      { status: 500 },
    );
  }
}
