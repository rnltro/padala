import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";
import { getUsdcToNearQuote, getSourceChain } from "@/lib/intents";
import { ensureSeed } from "@/lib/treasury";
import { initiateSettlement, quoteFeeBps } from "@/lib/settlement";

/**
 * Autopilot — the "autonomous payments" loop.
 *
 * A scheduler (cron-job.org, GitHub Actions, or `curl` in a loop) hits this
 * endpoint every couple of minutes. For every open invoice with Autopilot on,
 * the agent:
 *   1. fetches a fresh 1Click quote,
 *   2. compares the route fee against the invoice's maxFeeBps budget,
 *   3. executes the full settlement flow only when the fee fits (the spending
 *      policy still applies — autopilot never bypasses it),
 *   4. logs every decision (execute or skip + reason) to the audit trail.
 *
 * Auth: set CRON_SECRET to require `Authorization: Bearer <CRON_SECRET>`.
 * Unset = open (dev mode).
 */
export const dynamic = "force-dynamic";

const IN_FLIGHT = ["PENDING_DEPOSIT", "KNOWN_DEPOSIT_TX", "PROCESSING"];

async function handle(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers.get("authorization");
    if (auth !== `Bearer ${secret}`) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
  }

  await ensureSeed();

  const invoices = await db.invoice.findMany({
    where: { status: "AWAITING_PAYMENT", autoSettle: true },
    include: { payments: { orderBy: { createdAt: "desc" }, take: 1 } },
  });

  const results: Array<Record<string, unknown>> = [];
  let executed = 0;
  let skipped = 0;

  for (const invoice of invoices) {
    const chain = getSourceChain(invoice.autopilotChain);
    if (!chain) {
      skipped++;
      results.push({ reference: invoice.reference, action: "SKIP", reason: `unknown chain ${invoice.autopilotChain}` });
      continue;
    }

    // Don't stack quotes on top of a deposit that's already in flight.
    const latest = invoice.payments[0];
    if (latest && IN_FLIGHT.includes(latest.status)) {
      skipped++;
      results.push({ reference: invoice.reference, action: "SKIP_IN_FLIGHT", paymentStatus: latest.status });
      continue;
    }

    // Fresh quote — how expensive is the route right now?
    const probe = await getUsdcToNearQuote({
      chainId: chain.id,
      amountUsd: invoice.amountUsd,
      recipient: invoice.freelancerAccount,
      refundTo: invoice.refundAddress ?? undefined,
    });
    if (!probe.ok) {
      skipped++;
      await recordAudit(db, {
        type: "AUTOPILOT_SKIPPED",
        actor: ACTORS.agent,
        invoiceRef: invoice.reference,
        summary: `Autopilot skipped ${invoice.reference} — quote failed: ${probe.error}`,
        detail: { chainId: chain.id, error: probe.error },
      });
      results.push({ reference: invoice.reference, action: "SKIP", reason: "quote failed", error: probe.error });
      continue;
    }

    const feeBps = quoteFeeBps(probe.quote.amountIn, probe.quote.amountOut);
    if (feeBps === null || feeBps > invoice.maxFeeBps) {
      skipped++;
      await recordAudit(db, {
        type: "AUTOPILOT_SKIPPED",
        actor: ACTORS.agent,
        invoiceRef: invoice.reference,
        summary: `Autopilot skipped ${invoice.reference} — route fee ${feeBps ?? "unknown"} bps > budget ${invoice.maxFeeBps} bps`,
        detail: {
          chainId: chain.id,
          feeBps,
          budgetBps: invoice.maxFeeBps,
          amountIn: probe.quote.amountIn,
          amountOut: probe.quote.amountOut,
          note: "The agent re-quotes on the next tick instead of overpaying.",
        },
      });
      results.push({
        reference: invoice.reference,
        action: "SKIP_OVER_BUDGET",
        feeBps,
        budgetBps: invoice.maxFeeBps,
      });
      continue;
    }

    // In budget — execute. The spending policy still gates everything.
    const settlement = await initiateSettlement({ invoiceId: invoice.id, chainId: chain.id, trigger: "autopilot" });
    if (!settlement.ok) {
      skipped++;
      await recordAudit(db, {
        type: "AUTOPILOT_SKIPPED",
        actor: ACTORS.agent,
        invoiceRef: invoice.reference,
        summary: `Autopilot could not execute ${invoice.reference}: ${settlement.error}`,
        detail: { chainId: chain.id, error: settlement.error },
      });
      results.push({ reference: invoice.reference, action: "SKIP", reason: settlement.error });
      continue;
    }

    executed++;
    await recordAudit(db, {
      type: "AUTOPILOT_EXECUTED",
      actor: ACTORS.agent,
      invoiceRef: invoice.reference,
      summary: `Autopilot executed ${invoice.reference} — fee ${feeBps} bps within ${invoice.maxFeeBps} bps budget, deposit address issued (no human clicked)`,
      detail: {
        chainId: chain.id,
        feeBps,
        budgetBps: invoice.maxFeeBps,
        paymentId: settlement.payment.id,
        depositAddress: settlement.payment.depositAddress,
      },
    });
    results.push({ reference: invoice.reference, action: "EXECUTED", feeBps, budgetBps: invoice.maxFeeBps });
  }

  return NextResponse.json({
    checked: invoices.length,
    executed,
    skipped,
    results,
    ts: new Date().toISOString(),
  });
}

export { handle as GET, handle as POST };
