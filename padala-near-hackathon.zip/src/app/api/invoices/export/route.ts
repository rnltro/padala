import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";

/**
 * CSV ledger export — GET /api/invoices/export → padala-invoices-YYYY-MM-DD.csv
 *
 * One row per invoice: reference, client, status, created/due/settled dates,
 * settled amount, route fee bps, deposit address, refund path. UTF-8 BOM +
 * CRLF so it opens clean in Excel. An empty ledger exports headers only.
 * Every export (even empty) writes a CSV_EXPORTED audit event — an
 * accountant reconciling from this file leaves a trace, like everything else.
 */
export const dynamic = "force-dynamic";

function csvField(value: string | number | null | undefined): string {
  const s = value === null || value === undefined ? "" : String(value);
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

function csvRow(fields: (string | number | null | undefined)[]): string {
  return fields.map(csvField).join(",") + "\r\n";
}

function dateOr(iso: Date | null | undefined): string {
  return iso ? iso.toISOString().slice(0, 10) : "";
}

/** Route fee in bps from the quote math (amountOut vs amountIn), if we have both. */
function feeBps(amountInUsd: number, amountOutUsd: number | null): number | "" {
  if (!amountOutUsd || amountInUsd <= 0) return "";
  return Math.max(0, Math.round((1 - amountOutUsd / amountInUsd) * 10000));
}

export async function GET() {
  const invoices = await db.invoice.findMany({
    orderBy: { createdAt: "asc" },
    include: { payments: { orderBy: { createdAt: "desc" }, take: 1 } },
  });

  const today = new Date().toISOString().slice(0, 10);
  const filename = `padala-invoices-${today}.csv`;

  const header = [
    "Reference",
    "Client",
    "Status",
    "Created",
    "Due",
    "Settled",
    "Settled Amount (USD)",
    "Route Fee (bps)",
    "Deposit Address",
    "Refund Path",
    "Payroll Run",
  ];

  const rows = invoices.map((inv) => {
    const latest = inv.payments[0];
    return [
      inv.reference,
      inv.clientName,
      inv.status,
      dateOr(inv.createdAt),
      dateOr(inv.dueDate),
      dateOr(inv.paidAt),
      inv.status === "PAID" ? (latest?.amountOutUsd ?? latest?.amountInUsd ?? inv.amountUsd).toFixed(2) : "",
      latest ? feeBps(latest.amountInUsd, latest.amountOutUsd) : "",
      latest?.depositAddress ?? "",
      inv.refundPath ?? "",
      inv.payrollRunLabel ?? "",
    ];
  });

  const csv = "\uFEFF" + csvRow(header) + rows.map(csvRow).join("");

  await recordAudit(db, {
    type: "CSV_EXPORTED",
    actor: ACTORS.employer,
    summary: `Invoice ledger exported — ${rows.length} row${rows.length === 1 ? "" : "s"} (${filename})`,
    detail: { filename, rowCount: rows.length, totalLedgerUsd: invoices.reduce((s, i) => s + i.amountUsd, 0) },
  });

  return new NextResponse(csv, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}
