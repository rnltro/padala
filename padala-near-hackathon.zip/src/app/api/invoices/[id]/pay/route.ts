import { NextRequest, NextResponse } from "next/server";
import { initiateSettlement } from "@/lib/settlement";

/**
 * Pay an invoice from the agent treasury (human-triggered):
 * policy check -> live 1Click quote -> PENDING_DEPOSIT payment.
 * The employer sends USDC to the deposit address; solvers settle and the
 * freelancer's NEAR account receives native USDC in its Intents balance.
 * (Autopilot triggers the same flow on a schedule via /api/cron/settle.)
 */
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const body = await req.json().catch(() => ({}));
  const chainId = String(body.chainId ?? "");

  const result = await initiateSettlement({ invoiceId: id, chainId, trigger: "human" });

  if (!result.ok) {
    return NextResponse.json(
      { error: result.error, ...(result.decision ? { decision: result.decision } : {}) },
      { status: result.status },
    );
  }
  return NextResponse.json(
    { payment: result.payment, decision: result.decision, quote: result.quote },
    { status: 201 },
  );
}
