import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";
import { getSourceChain } from "@/lib/intents";

/**
 * Update an invoice's Autopilot settings:
 *   { autoSettle?: boolean, maxFeeBps?: number, autopilotChain?: string }
 * Autopilot lets the agent settle the invoice on its own when the live 1Click
 * fee is within `maxFeeBps`. Every change lands in the audit trail.
 */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const body = await req.json().catch(() => ({}));
    const invoice = await db.invoice.findUnique({ where: { id } });
    if (!invoice) return NextResponse.json({ error: "Invoice not found" }, { status: 404 });
    if (invoice.status === "PAID") {
      return NextResponse.json({ error: "Invoice is already paid" }, { status: 409 });
    }

    const data: { autoSettle?: boolean; maxFeeBps?: number; autopilotChain?: string } = {};

    if (body.autoSettle !== undefined) data.autoSettle = Boolean(body.autoSettle);

    if (body.maxFeeBps !== undefined) {
      const bps = Math.round(Number(body.maxFeeBps));
      if (!Number.isFinite(bps) || bps < 1 || bps > 1000) {
        return NextResponse.json({ error: "maxFeeBps must be between 1 and 1000 (0.01%–10%)" }, { status: 400 });
      }
      data.maxFeeBps = bps;
    }

    if (body.autopilotChain !== undefined) {
      if (!getSourceChain(String(body.autopilotChain))) {
        return NextResponse.json({ error: "autopilotChain must be one of base, eth, arb, sol" }, { status: 400 });
      }
      data.autopilotChain = String(body.autopilotChain);
    }

    if (Object.keys(data).length === 0) {
      return NextResponse.json({ error: "Nothing to update (autoSettle, maxFeeBps, autopilotChain)" }, { status: 400 });
    }

    const updated = await db.invoice.update({ where: { id }, data });

    await recordAudit(db, {
      type: "AUTOPILOT_UPDATED",
      actor: ACTORS.employer,
      invoiceRef: updated.reference,
      summary: updated.autoSettle
        ? `Autopilot ENABLED for ${updated.reference} — agent may settle via ${updated.autopilotChain.toUpperCase()} when fee ≤ ${(updated.maxFeeBps / 100).toFixed(2)}%`
        : `Autopilot DISABLED for ${updated.reference}`,
      detail: { ...data, reference: updated.reference },
    });

    return NextResponse.json({ invoice: updated });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to update invoice" },
      { status: 500 },
    );
  }
}
