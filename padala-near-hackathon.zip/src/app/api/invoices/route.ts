import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";
import { deriveRefundAddress } from "@/lib/chainsignatures";
import { ensureSeed } from "@/lib/treasury";
import { validateSingleInvoiceFields } from "@/lib/invoicing";

export async function GET() {
  await ensureSeed();
  const invoices = await db.invoice.findMany({
    orderBy: { createdAt: "desc" },
    include: { payments: { orderBy: { createdAt: "desc" } } },
  });
  return NextResponse.json({ invoices });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const clientName = String(body.clientName ?? "").trim();
    const description = String(body.description ?? "").trim();
    const freelancerAccount = String(body.freelancerAccount ?? "").trim();
    const amountUsd = Number(body.amountUsd);
    const dueDate = body.dueDate ? new Date(body.dueDate) : null;

    // Shared validation — batch payroll (POST /api/payroll-runs) enforces the
    // exact same rules per line (src/lib/invoicing.ts, covered by bun test).
    const validationError = validateSingleInvoiceFields({ clientName, description, amountUsd, freelancerAccount });
    if (validationError) {
      return NextResponse.json({ error: validationError }, { status: 400 });
    }
    if (!dueDate || Number.isNaN(dueDate.getTime())) {
      return NextResponse.json({ error: "dueDate must be a valid date" }, { status: 400 });
    }

    const count = await db.invoice.count();
    const reference = `INV-${1001 + count}`;

    // Autopilot inputs (optional): agent may settle this invoice on its own.
    const autoSettle = body.autoSettle === true;
    let maxFeeBps = Math.round(Number(body.maxFeeBps ?? 100));
    if (!Number.isFinite(maxFeeBps) || maxFeeBps < 1) maxFeeBps = 1;
    if (maxFeeBps > 1000) maxFeeBps = 1000;

    // Per-invoice refund address derived from the NEAR MPC root key
    // (Chain Signatures). The private key never exists anywhere; if derivation
    // fails (e.g. offline dev), we continue and the pay flow uses the
    // per-chain fallback wallet instead.
    const refund = await deriveRefundAddress(reference);

    const invoice = await db.invoice.create({
      data: {
        reference,
        clientName,
        description,
        amountUsd: Math.round(amountUsd * 100) / 100,
        dueDate,
        freelancerAccount,
        refundAddress: refund.ok ? refund.address : null,
        refundPath: refund.ok ? refund.path : null,
        autoSettle,
        maxFeeBps,
      },
    });

    if (refund.ok) {
      await recordAudit(db, {
        type: "REFUND_ADDRESS_DERIVED",
        actor: ACTORS.system,
        invoiceRef: reference,
        summary: `Refund address ${refund.address} derived from NEAR MPC root key — path "${refund.path}" for ${refund.signerId} (key never exists anywhere)`,
        detail: {
          derivationPath: refund.path,
          signerId: refund.signerId,
          mpcRootKey: refund.rootKeyNaj,
          scheme: "near/mpc epsilon derivation (sha3_256 tweak + secp256k1)",
        },
      });
    }

    await recordAudit(db, {
      type: "INVOICE_CREATED",
      actor: ACTORS.system,
      summary: `Invoice ${reference} issued to ${clientName} for $${invoice.amountUsd.toFixed(2)} — payable to ${freelancerAccount} on NEAR${autoSettle ? ` (autopilot ≤ ${(maxFeeBps / 100).toFixed(2)}%)` : ""}`,
      invoiceRef: reference,
      detail: {
        amountUsd: invoice.amountUsd,
        freelancerAccount,
        clientName,
        autoSettle,
        maxFeeBps,
        refundAddress: refund.ok ? refund.address : null,
        refundError: refund.ok ? null : refund.error,
      },
    });

    return NextResponse.json({ invoice }, { status: 201 });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : "Failed to create invoice" },
      { status: 500 },
    );
  }
}
