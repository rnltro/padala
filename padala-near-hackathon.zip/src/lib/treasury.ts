import { db } from "@/lib/db";
import { ACTORS } from "@/lib/audit";
import { deriveRefundAddress } from "@/lib/chainsignatures";
import type { Policy } from "@prisma/client";

export const AGENT_ACCOUNT = "agent.padala.near";
export const AGENT_DESCRIPTION = "Padala Agent — employer treasury agent with spending policy";
/** Demo starting balance of USDC on NEAR (Intents balance) for the agent treasury. */
export const TREASURY_START_USDC = 12500;

/** Get (or create) the singleton spending policy. Race-safe via upsert. */
export async function ensurePolicy(): Promise<Policy> {
  return db.policy.upsert({
    where: { id: "default" },
    update: {},
    create: { id: "default" },
  });
}

/** Total USDC settled out of the treasury (payments that reached SUCCESS). */
export async function settledTotalUsd(): Promise<number> {
  const agg = await db.payment.aggregate({
    _sum: { amountInUsd: true },
    where: { status: "SUCCESS" },
  });
  return agg._sum.amountInUsd ?? 0;
}

/** USDC settled today (UTC) — the number the daily cap guards. */
export async function settledTodayUsd(): Promise<number> {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);
  const agg = await db.payment.aggregate({
    _sum: { amountInUsd: true },
    where: { status: "SUCCESS", settledAt: { gte: startOfDay } },
  });
  return agg._sum.amountInUsd ?? 0;
}

export async function treasuryBalanceUsdc(): Promise<number> {
  return Math.round((TREASURY_START_USDC - (await settledTotalUsd())) * 100) / 100;
}

/**
 * Idempotent demo seed: two invoices + matching audit history, so the
 * dashboard tells a story the moment the app opens.
 * Race-safe: concurrent calls are serialized through a promise chain, and a
 * parallel-process race is swallowed (unique `reference` makes the loser bail,
 * the winner's rows are the correct end state). The chain is intentionally
 * NOT cached forever — after `scripts/reset-demo.ts` clears the DB, the next
 * API call re-seeds instead of returning an empty dashboard.
 */
let seedChain: Promise<void> = Promise.resolve();

export function ensureSeed(): Promise<void> {
  const run = seedChain
    .then(() => doSeed())
    .catch((err) => {
      console.warn("[seed] skipped:", err instanceof Error ? err.message : err);
    });
  seedChain = run;
  return run;
}

async function doSeed(): Promise<void> {
  const policy = await ensurePolicy();
  const invoiceCount = await db.invoice.count();
  if (invoiceCount > 0) return;

  const now = Date.now();
  const day = 24 * 60 * 60 * 1000;

  // Seed invoices also get per-invoice MPC-derived refund addresses (Chain
  // Signatures) so the dashboard shows the feature from the first paint.
  // Offline dev silently falls back to null → per-chain fallback wallet.
  // Both derivations run concurrently so a slow NEAR RPC only costs ~8s.
  const [refund1001, refund1002] = await Promise.all([
    deriveRefundAddress("INV-1001"),
    deriveRefundAddress("INV-1002"),
  ]);
  const refund1001Fields = refund1001.ok
    ? { refundAddress: refund1001.address, refundPath: refund1001.path }
    : {};
  const refund1002Fields = refund1002.ok
    ? { refundAddress: refund1002.address, refundPath: refund1002.path }
    : {};

  const paidInvoice = await db.invoice.create({
    data: {
      reference: "INV-1001",
      clientName: "Acme Studio",
      description: "Landing page design + build (milestone 1 of 2)",
      amountUsd: 950,
      status: "PAID",
      dueDate: new Date(now - day),
      freelancerAccount: "maria.padala.near",
      createdAt: new Date(now - 3 * day),
      paidAt: new Date(now - 2 * day),
      ...refund1001Fields,
    },
  });

  await db.payment.create({
    data: {
      invoiceId: paidInvoice.id,
      sourceChain: "base",
      sourceAsset: "nep141:base-0x833589fcd6edb6e08f4c7c32d4f71b54bda02913.omft.near",
      amountInUsd: 950,
      amountOut: "949616800", // 949.6168 USDC @ 6 decimals
      amountOutUsd: 949.62,
      depositAddress: "0xA11ce0000000000000000000000000000000dEa1",
      timeEstimate: 35,
      status: "SUCCESS",
      simulated: true,
      createdAt: new Date(now - 2 * day),
      settledAt: new Date(now - 2 * day + 40_000),
    },
  });

  await db.invoice.create({
    data: {
      reference: "INV-1002",
      clientName: "Northwind Labs",
      description: "React Native app maintenance — November retainer",
      amountUsd: 1800,
      status: "AWAITING_PAYMENT",
      dueDate: new Date(now + 5 * day),
      freelancerAccount: "maria.padala.near",
      createdAt: new Date(now - day),
      ...refund1002Fields,
    },
  });

  const seedEvents: Array<{
    type: string;
    actor: string;
    summary: string;
    invoiceRef?: string;
    at: Date;
    detail?: Record<string, unknown>;
  }> = [
    {
      type: "POLICY_UPDATED",
      actor: ACTORS.employer,
      summary: "Agent policy configured — $2,500/tx, $7,500/day, auto-approve under $1,000",
      at: new Date(now - 4 * day),
      detail: { perTxLimitUsd: policy.perTxLimitUsd, dailyLimitUsd: policy.dailyLimitUsd },
    },
    {
      type: "INVOICE_CREATED",
      actor: ACTORS.system,
      summary: "Invoice INV-1001 issued to Acme Studio for $950.00",
      invoiceRef: "INV-1001",
      at: new Date(now - 3 * day),
    },
    {
      type: "POLICY_CHECK",
      actor: ACTORS.agent,
      summary: "Policy PASS (AUTO_APPROVED) for $950.00 via BASE — 6/6 checks green",
      invoiceRef: "INV-1001",
      at: new Date(now - 2 * day),
      detail: { mode: "AUTO_APPROVED", checksPassed: 6, checksFailed: 0 },
    },
    {
      type: "QUOTE_REQUESTED",
      actor: ACTORS.agent,
      summary: "1Click quote: 950 USDC (Base) → 949.62 USDC (NEAR), ~35s settle",
      invoiceRef: "INV-1001",
      at: new Date(now - 2 * day),
    },
    {
      type: "PAYMENT_INITIATED",
      actor: ACTORS.agent,
      summary: "Deposit requested — employer to send 950 USDC to deposit address on Base",
      invoiceRef: "INV-1001",
      at: new Date(now - 2 * day),
    },
    {
      type: "PAYMENT_SETTLED_SIMULATED",
      actor: ACTORS.system,
      summary: "Settlement confirmed — 949.62 USDC credited to maria.padala.near on NEAR",
      invoiceRef: "INV-1001",
      at: new Date(now - 2 * day + 40_000),
      detail: { simulated: true, note: "Demo settlement — production settles via 1Click status polling" },
    },
    {
      type: "INVOICE_CREATED",
      actor: ACTORS.system,
      summary: "Invoice INV-1002 issued to Northwind Labs for $1,800.00",
      invoiceRef: "INV-1002",
      at: new Date(now - day),
    },
  ];

  // Record the derivations in the audit trail (only when they succeeded).
  const refundEvents = [refund1001, refund1002]
    .map((r, i) => ({ r, ref: i === 0 ? "INV-1001" : "INV-1002" }))
    .filter((x) => x.r.ok);
  for (const { r, ref } of refundEvents) {
    if (!r.ok) continue;
    seedEvents.push({
      type: "REFUND_ADDRESS_DERIVED",
      actor: ACTORS.system,
      summary: `Refund address ${r.address} derived from NEAR MPC root key — path "${r.path}" for ${r.signerId} (key never exists anywhere)`,
      invoiceRef: ref,
      at: new Date(now - day),
      detail: { derivationPath: r.path, signerId: r.signerId, mpcRootKey: r.rootKeyNaj },
    });
  }

  for (const e of seedEvents) {
    await db.auditEvent.create({
      data: {
        type: e.type,
        actor: e.actor,
        summary: e.summary,
        detail: JSON.stringify(e.detail ?? {}),
        invoiceRef: e.invoiceRef ?? null,
        createdAt: e.at,
      },
    });
  }
}
