/**
 * NEAR Chain Signatures — MPC-derived per-invoice refund addresses.
 *
 * Why: a failed 1Click swap refunds to `refundTo` on the origin chain.
 * Hardcoding one EOA there (a) leaks a wallet we don't control policies for
 * and (b) means every invoice shares a refund sink. Instead, Padala derives a
 * unique, deterministic refund address per invoice from the NEAR MPC network's
 * root key — the private key never exists anywhere (not in this app, not in
 * any TEE, not on the MPC network itself: it is never reconstructed).
 *
 * Algorithm (matches near/mpc's KDF, pinned against the live contract output
 * via scripts/verify-derivation.ts — see that file for the test vector):
 *   tweak = sha3_256("near-mpc-recovery v0.1.0 epsilon derivation:" + predecessor + "," + path)
 *   child = root_point + tweak * G            (secp256k1)
 *   evm   = EIP-55( keccak256(child_pub[1..65])[-20..] )
 *
 * References:
 *   - Contract: v1.signer (mainnet) — method `public_key`
 *   - KDF: near/mpc crates/near-mpc-crypto-types/src/kdf.rs (epsilon derivation)
 *   - Upstream TS: NearDeFi/chainsig.js (najToUncompressedPubKeySEC1 / deriveChildPublicKey)
 */

import { secp256k1 } from "@noble/curves/secp256k1";
import { keccak_256, sha3_256 } from "@noble/hashes/sha3";
import { base58 } from "@scure/base";

const EPSILON_PREFIX = "near-mpc-recovery v0.1.0 epsilon derivation:";

/** MPC signer contract. Testnet equivalent: v1.signer-testnet. */
export const MPC_CONTRACT_ID = process.env.CHAIN_SIGNATURES_CONTRACT || "v1.signer";
/** The NEAR account "requesting" derivations — becomes part of each child key. */
export const PADALA_SIGNER_ID = process.env.PADALA_SIGNER_ID || "agent.padala.near";
const NEAR_RPC_URL = process.env.NEAR_RPC_URL || "https://rpc.mainnet.near.org";
const ROOT_KEY_TTL_MS = 60 * 60 * 1000;

type RootKey = { naj: string; sec1: string };
let rootKeyCache: (RootKey & { at: number }) | null = null;

/** `refund-INV-1042` — stable per invoice, shown in the UI and audit log. */
export function refundDerivationPath(reference: string): string {
  return `refund-${reference}`;
}

/** NAJ (`secp256k1:<base58 of x||y>`) → uncompressed SEC1 hex (`04||x||y`). */
function najToUncompressedSec1(naj: string): string {
  const [scheme, key] = naj.split(":");
  if (scheme !== "secp256k1" || !key) throw new Error(`Unsupported MPC key format: ${naj.slice(0, 24)}…`);
  return "04" + Buffer.from(base58.decode(key)).toString("hex");
}

/**
 * Root public key of the MPC network. Fetched from the contract over NEAR RPC
 * (cached 1h). Set MPC_PUBLIC_KEY=secp256k1:... to pin it and run fully offline.
 */
export async function getMpcRootPublicKey(): Promise<RootKey> {
  const pinned = process.env.MPC_PUBLIC_KEY?.trim();
  if (pinned) return { naj: pinned, sec1: najToUncompressedSec1(pinned) };

  if (rootKeyCache && Date.now() - rootKeyCache.at < ROOT_KEY_TTL_MS) {
    return { naj: rootKeyCache.naj, sec1: rootKeyCache.sec1 };
  }

  const res = await fetch(NEAR_RPC_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: "padala",
      method: "query",
      params: {
        request_type: "call_function",
        account_id: MPC_CONTRACT_ID,
        method_name: "public_key",
        args_base64: Buffer.from("{}").toString("base64"),
        finality: "final",
      },
    }),
    signal: AbortSignal.timeout(8_000),
  });
  const data = (await res.json()) as {
    result?: { result?: number[]; error?: { panic_msg?: string } | string };
    error?: { message?: string };
  };
  const rpcErr = data?.result?.error ?? data?.error;
  if (rpcErr) {
    let msg = "unknown RPC error";
    if (typeof rpcErr === "string") msg = rpcErr;
    else if ("panic_msg" in rpcErr && rpcErr.panic_msg) msg = rpcErr.panic_msg;
    else if ("message" in rpcErr && rpcErr.message) msg = rpcErr.message;
    throw new Error(`MPC public_key query failed: ${msg}`);
  }
  const raw = Buffer.from(data.result?.result ?? []).toString().trim();
  const naj = (raw.startsWith('"') ? JSON.parse(raw) : raw) as string;
  rootKeyCache = { naj, sec1: najToUncompressedSec1(naj), at: Date.now() };
  return { naj, sec1: rootKeyCache.sec1 };
}

/** tweak*G + root — the near/mpc epsilon derivation. Pure function. */
export function deriveChildSec1PublicKey(rootSec1: string, predecessor: string, path: string): string {
  const tweakBytes = sha3_256(new TextEncoder().encode(`${EPSILON_PREFIX}${predecessor},${path}`));
  const scalar = BigInt("0x" + Buffer.from(tweakBytes).toString("hex")) % secp256k1.CURVE.n;
  const child = secp256k1.ProjectivePoint.fromHex(rootSec1).add(
    secp256k1.ProjectivePoint.BASE.multiply(scalar),
  );
  return Buffer.from(child.toRawBytes(false)).toString("hex");
}

/** EIP-55 checksummed address from a 64-byte public key (keccak, last 20 bytes). */
export function evmAddressFromSec1(sec1: string): string {
  const body = sec1.startsWith("04") ? sec1.slice(2) : sec1;
  const hash = Buffer.from(keccak_256(Buffer.from(body, "hex"))).toString("hex");
  const lower = hash.slice(-40);
  const addrHash = Buffer.from(keccak_256(new TextEncoder().encode(lower))).toString("hex");
  let out = "0x";
  for (let i = 0; i < 40; i++) {
    out += parseInt(addrHash[i], 16) >= 8 ? lower[i].toUpperCase() : lower[i];
  }
  return out;
}

export type DerivedRefund =
  | { ok: true; address: string; path: string; signerId: string; rootKeyNaj: string }
  | { ok: false; error: string };

/**
 * Derive this invoice's EVM refund address via the MPC root key.
 * Never throws — an offline dev machine still gets a working invoice
 * (the pay flow falls back to the per-chain wallet in that case).
 */
export async function deriveRefundAddress(reference: string): Promise<DerivedRefund> {
  const path = refundDerivationPath(reference);
  try {
    const { naj, sec1 } = await getMpcRootPublicKey();
    const child = deriveChildSec1PublicKey(sec1, PADALA_SIGNER_ID, path);
    return { ok: true, address: evmAddressFromSec1(child), path, signerId: PADALA_SIGNER_ID, rootKeyNaj: naj };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "derivation failed" };
  }
}
