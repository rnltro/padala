import { PrismaClient } from "@prisma/client";
import { ensureSeed } from "@/lib/treasury";

/**
 * Clear every demo table and re-seed back to the pristine state
 * (2 invoices: INV-1001 PAID + INV-1002 awaiting, plus their audit history).
 * Shared by `bun scripts/reset-demo.ts` (CLI) and POST /api/demo/reset
 * (hosted-demo hygiene between judging sessions).
 */
export async function resetDemoData(db: PrismaClient): Promise<{
  cleared: { payments: number; invoices: number; auditEvents: number; policies: number; payrollRuns: number };
}> {
  // Order matters only for readability — SQLite FKs cascade from Payment→Invoice.
  const [payments, invoices, auditEvents, policies, payrollRuns] = await db.$transaction([
    db.payment.deleteMany(),
    db.invoice.deleteMany(),
    db.auditEvent.deleteMany(),
    db.policy.deleteMany(),
    db.payrollRun.deleteMany(),
  ]);

  // Re-run the seed immediately so the next dashboard paint shows the
  // pristine story (and the SEED audit events) without a cold first load.
  await ensureSeed();

  return {
    cleared: {
      payments: payments.count,
      invoices: invoices.count,
      auditEvents: auditEvents.count,
      policies: policies.count,
      payrollRuns: payrollRuns.count,
    },
  };
}
