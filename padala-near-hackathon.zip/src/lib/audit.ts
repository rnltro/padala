import type { PrismaClient } from "@prisma/client";

/** Actors used across the audit trail. */
export const ACTORS = {
  agent: "agent.padala.near",
  employer: "employer (human sign-off)",
  system: "system",
} as const;

export async function recordAudit(
  db: PrismaClient,
  event: {
    type: string;
    actor: string;
    summary: string;
    detail?: Record<string, unknown>;
    invoiceRef?: string;
  },
) {
  return db.auditEvent.create({
    data: {
      type: event.type,
      actor: event.actor,
      summary: event.summary,
      detail: JSON.stringify(event.detail ?? {}),
      invoiceRef: event.invoiceRef ?? null,
    },
  });
}
