/**
 * Policy engine for the Padala agent wallet ("AI Security & Defense" layer).
 *
 * Pure function: given the stored policy and the proposed payment, decide
 * ALLOW / BLOCK and produce human-readable checks for the audit trail.
 * In production these same checks run inside a Shade Agent (TEE) before a
 * chain-signature transaction is ever signed; here they gate the API.
 */

export type PolicyRecord = {
  enabled: boolean;
  perTxLimitUsd: number;
  dailyLimitUsd: number;
  autoApproveUnderUsd: number;
  allowedChains: string; // csv
  allowedRecipients: string; // csv, empty = any
};

export type PolicyCheck = {
  name: string;
  label: string;
  passed: boolean;
  detail: string;
};

export type PolicyDecision = {
  allowed: boolean;
  mode: "AUTO_APPROVED" | "WITHIN_LIMITS" | "BLOCKED";
  checks: PolicyCheck[];
  blockedReasons: string[];
};

export type PolicyInput = {
  policy: PolicyRecord;
  amountUsd: number;
  sourceChain: string;
  recipient: string; // freelancer NEAR account
  spentTodayUsd: number;
  treasuryUsdc: number;
};

function parseCsv(value: string): string[] {
  return value
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

export function evaluatePolicy(input: PolicyInput): PolicyDecision {
  const { policy, amountUsd, sourceChain, recipient, spentTodayUsd, treasuryUsdc } = input;
  const fmt = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 2 })}`;

  const checks: PolicyCheck[] = [];
  const push = (name: string, label: string, passed: boolean, detail: string) =>
    checks.push({ name, label, passed, detail });

  push(
    "agent_enabled",
    "Agent wallet enabled",
    policy.enabled,
    policy.enabled ? "Agent is active and allowed to move treasury funds" : "Agent is paused — all payments blocked",
  );

  const perTxOk = amountUsd <= policy.perTxLimitUsd;
  push(
    "per_tx_limit",
    "Per-transaction limit",
    perTxOk,
    `${fmt(amountUsd)} vs limit ${fmt(policy.perTxLimitUsd)}`,
  );

  const dailyOk = spentTodayUsd + amountUsd <= policy.dailyLimitUsd;
  push(
    "daily_cap",
    "Daily spend cap",
    dailyOk,
    `${fmt(spentTodayUsd)} spent today + ${fmt(amountUsd)} vs cap ${fmt(policy.dailyLimitUsd)}`,
  );

  const chainOk = parseCsv(policy.allowedChains).includes(sourceChain.toLowerCase());
  push(
    "chain_allowlist",
    "Source chain allowed",
    chainOk,
    chainOk ? `USDC on ${sourceChain.toUpperCase()} is an accepted funding rail` : `${sourceChain.toUpperCase()} is not on the allowlist`,
  );

  const recipients = parseCsv(policy.allowedRecipients);
  const recipientOk = recipients.length === 0 || recipients.includes(recipient.toLowerCase());
  push(
    "recipient_allowlist",
    "Recipient allowlist",
    recipientOk,
    recipientOk
      ? recipients.length === 0
        ? `Any NEAR account allowed (no allowlist configured) — paying ${recipient}`
        : `${recipient} is on the approved payee list`
      : `${recipient} is not an approved payee`,
  );

  const treasuryOk = treasuryUsdc >= amountUsd;
  push(
    "treasury_balance",
    "Treasury sufficient",
    treasuryOk,
    `${fmt(treasuryUsdc)} available vs ${fmt(amountUsd)} requested`,
  );

  const blockedReasons = checks.filter((c) => !c.passed).map((c) => `${c.label}: ${c.detail}`);
  const allowed = blockedReasons.length === 0;
  const mode: PolicyDecision["mode"] = !allowed
    ? "BLOCKED"
    : amountUsd <= policy.autoApproveUnderUsd
      ? "AUTO_APPROVED"
      : "WITHIN_LIMITS";

  return { allowed, mode, checks, blockedReasons };
}
