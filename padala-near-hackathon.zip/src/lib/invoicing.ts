/**
 * Shared invoice validation + batch-payroll helpers ("single + batch").
 *
 * Pure functions only — no DB, no I/O — so both the single-invoice route
 * (POST /api/invoices) and the batch route (POST /api/payroll-runs) enforce
 * exactly the same rules, and the unit tests (tests/invoicing.test.ts) can
 * cover them without a server.
 */

/** NEAR account (named) or hex EVM address — the invoice payee. */
export const FREELANCER_ACCOUNT_RE =
  /^[a-z0-9_.-]+\.near$|^[a-z0-9_.-]+\.testnet$|^[a-f0-9]{64}$/i;

export const MAX_INVOICE_USD = 1_000_000;
export const MAX_PAYROLL_LINES = 50;

export type InvoiceLineInput = {
  clientName: string;
  amountUsd: number;
  freelancerAccount: string;
};

export type InvoiceLine = InvoiceLineInput & {
  amountUsd: number; // rounded to cents
};

export type LineError = { line: number; error: string };

/**
 * Validate one payroll line. Returns the normalized line or a human error.
 * All-or-nothing philosophy: the caller validates EVERY line first and
 * refuses to write anything if any line fails.
 */
export function validateInvoiceLine(
  raw: unknown,
  lineNo: number,
): { ok: true; line: InvoiceLine } | { ok: false; error: string } {
  if (typeof raw !== "object" || raw === null) {
    return { ok: false, error: "line must be an object { clientName, amountUsd, freelancerAccount }" };
  }
  const { clientName, amountUsd, freelancerAccount } = raw as Record<string, unknown>;

  const name = String(clientName ?? "").trim();
  if (!name) return { ok: false, error: "clientName is required" };
  if (name.length > 120) return { ok: false, error: "clientName is too long (max 120 chars)" };

  const account = String(freelancerAccount ?? "").trim();
  if (!account) return { ok: false, error: "freelancerAccount is required" };
  if (!FREELANCER_ACCOUNT_RE.test(account)) {
    return { ok: false, error: `freelancerAccount "${account}" must look like a NEAR account (e.g. maria.padala.near)` };
  }

  const amount = Number(amountUsd);
  if (!Number.isFinite(amount) || amount <= 0) {
    return { ok: false, error: `amountUsd "${String(amountUsd)}" must be a positive number` };
  }
  if (amount > MAX_INVOICE_USD) {
    return { ok: false, error: `amountUsd ${amount} exceeds the ${MAX_INVOICE_USD} maximum` };
  }

  return { ok: true, line: { clientName: name, amountUsd: Math.round(amount * 100) / 100, freelancerAccount: account } };
}

/** Same rules as validateInvoiceLine, for the single-invoice form fields. */
export function validateSingleInvoiceFields(fields: {
  clientName: string;
  description: string;
  amountUsd: number;
  freelancerAccount: string;
}): string | null {
  if (!fields.clientName.trim()) return "clientName is required";
  if (!fields.description.trim()) return "description is required";
  const amount = Number(fields.amountUsd);
  if (!Number.isFinite(amount) || amount <= 0) return "amountUsd must be a positive number";
  if (amount > MAX_INVOICE_USD) return `amountUsd exceeds the ${MAX_INVOICE_USD} maximum`;
  if (!FREELANCER_ACCOUNT_RE.test(fields.freelancerAccount.trim())) {
    return "freelancerAccount must look like a NEAR account (e.g. maria.padala.near)";
  }
  return null;
}

/**
 * Policy pre-flight for a batch run — does NOT block (the spending policy
 * still gates every settlement individually at pay time), it warns so the
 * employer sees the conflict before the run exists.
 */
export function policyPreFlight(
  lines: { amountUsd: number }[],
  policy: { perTxLimitUsd: number; dailyLimitUsd: number },
): string[] {
  const warnings: string[] = [];
  const fmt = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 2 })}`;
  const total = lines.reduce((s, l) => s + l.amountUsd, 0);

  for (const l of lines) {
    if (l.amountUsd > policy.perTxLimitUsd) {
      warnings.push(
        `Line "${l.amountUsd}" exceeds the per-tx limit ${fmt(policy.perTxLimitUsd)} — the payment will be BLOCKED by the spending policy at pay time`,
      );
    }
  }
  if (total > policy.dailyLimitUsd) {
    warnings.push(
      `Run total ${fmt(total)} exceeds the daily cap ${fmt(policy.dailyLimitUsd)} — settlements past today's remaining budget will be BLOCKED`,
    );
  }
  return warnings;
}

/**
 * Parse a pasted payroll block: one freelancer per line,
 * `Client name, 1450, maria.padala.near` (commas or tabs — spreadsheets
 * paste with tabs). Empty lines and #comments are skipped.
 */
export function parsePayrollText(text: string): { lines: InvoiceLineInput[]; errors: LineError[] } {
  const lines: InvoiceLineInput[] = [];
  const errors: LineError[] = [];
  let lineNo = 0;

  for (const raw of text.split("\n")) {
    lineNo += 1;
    const trimmed = raw.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const parts = trimmed.split(/\t|,/).map((p) => p.trim()).filter(Boolean);
    if (parts.length < 3) {
      errors.push({ line: lineNo, error: "expected: client name, amount, NEAR account" });
      continue;
    }
    if (parts.length > 3) {
      errors.push({ line: lineNo, error: "too many fields — expected: client name, amount, NEAR account" });
      continue;
    }
    const amount = Number(parts[1]);
    if (!Number.isFinite(amount)) {
      errors.push({ line: lineNo, error: `"${parts[1]}" is not a number` });
      continue;
    }
    lines.push({ clientName: parts[0], amountUsd: amount, freelancerAccount: parts[2] });
  }
  return { lines, errors };
}
