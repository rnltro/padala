/**
 * NEAR Intents (1Click Swap API) client.
 * Docs: https://docs.near-intents.org/integration/distribution-channels/1click-api/
 *
 * Flow used by Padala (Real-World Money track):
 *   1. Client (employer) pays an invoice in USDC from any supported chain.
 *   2. 1Click gives us a quote + a per-swap deposit address on the source chain.
 *   3. Employer sends USDC to that address.
 *   4. Solvers settle and the freelancer receives native USDC on NEAR
 *      (recipientType: INTENTS -> lands in the freelancer's NEAR Intents balance).
 *   5. We poll GET /v0/status?depositAddress=... until SUCCESS.
 */

const ONECLICK = "https://1click.chaindefuser.com/v0";

/** Native USDC on NEAR (assetId observed live from /v0/tokens, decimals = 6). */
export const NEAR_USDC_ASSET =
  "nep141:17208628f84f5d6ad33f0da3bbbeb27ffcb398eac501a31bd6ad2011e36133a1";

export const USDC_DECIMALS = 6;

export type SourceChain = {
  id: string;
  label: string;
  /** 1Click assetId for native USDC on this chain (verified live 2026-11-04). */
  assetId: string;
  /** FALLBACK refund wallet — only used when an invoice has no MPC-derived
   *  address (seed data / offline dev). Real invoices carry a per-invoice
   *  Chain-Signatures refund address (see src/lib/chainsignatures.ts). */
  refundTo: string;
  note: string;
};

export const SOURCE_CHAINS: SourceChain[] = [
  {
    id: "base",
    label: "Base",
    assetId: "nep141:base-0x833589fcd6edb6e08f4c7c32d4f71b54bda02913.omft.near",
    refundTo: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    note: "Coinbase L2 — cheapest corridor",
  },
  {
    id: "eth",
    label: "Ethereum",
    assetId: "nep141:eth-0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48.omft.near",
    refundTo: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    note: "Mainnet USDC",
  },
  {
    id: "arb",
    label: "Arbitrum",
    assetId: "nep141:arb-0xaf88d065e77c8cc2239327c5edb3a432268e5831.omft.near",
    refundTo: "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045",
    note: "Orbit ecosystem payouts",
  },
  {
    id: "sol",
    label: "Solana",
    assetId: "nep141:sol-5ce3bf3a31af18be40ba30f721101b4341690186.omft.near",
    refundTo: "So11111111111111111111111111111111111111112",
    note: "SPL USDC",
  },
];

export function getSourceChain(id: string): SourceChain | undefined {
  return SOURCE_CHAINS.find((c) => c.id === id);
}

export type Quote = {
  depositAddress: string;
  amountIn: string;
  amountInUsd: string;
  amountOut: string;
  amountOutFormatted: string;
  amountOutUsd: string;
  minAmountOut: string;
  timeEstimate: number; // seconds
  deadline: string; // ISO
  refundFee: string;
  withdrawFee: string;
};

type RawQuoteResponse = {
  quote?: Partial<Quote>;
  quoteRequest?: unknown;
  message?: string;
};

export type QuoteResult =
  | { ok: true; quote: Quote; live: true }
  | { ok: false; error: string; live: true };

/**
 * Request a live quote: source-chain USDC -> native USDC on NEAR.
 * `recipientType: INTENTS` credits the freelancer's NEAR Intents balance.
 * A quote is inert until someone actually deposits, so it is safe to create.
 */
export async function getUsdcToNearQuote(params: {
  chainId: string;
  amountUsd: number;
  recipient: string; // freelancer NEAR account
  /** Per-invoice MPC-derived refund address (Chain Signatures). Falls back to
   *  the chain's demo wallet when absent. */
  refundTo?: string;
}): Promise<QuoteResult> {
  const chain = getSourceChain(params.chainId);
  if (!chain) return { ok: false, error: `Unsupported chain: ${params.chainId}`, live: true };

  const amountRaw = BigInt(Math.round(params.amountUsd * 10 ** USDC_DECIMALS)).toString();
  const deadline = new Date(Date.now() + 30 * 60 * 1000).toISOString();

  const body = {
    dry: false,
    swapType: "EXACT_INPUT",
    slippageTolerance: 100, // 1%
    originAsset: chain.assetId,
    depositType: "ORIGIN_CHAIN",
    destinationAsset: NEAR_USDC_ASSET,
    amount: amountRaw,
    recipient: params.recipient,
    recipientType: "INTENTS",
    refundTo: params.refundTo || chain.refundTo,
    refundType: "ORIGIN_CHAIN",
    deadline,
  };

  try {
    const res = await fetch(`${ONECLICK}/quote`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15_000),
    });
    const data = (await res.json()) as RawQuoteResponse;
    const q = data.quote;
    if (!res.ok || !q?.depositAddress) {
      return {
        ok: false,
        error: data.message ?? `1Click quote failed (HTTP ${res.status})`,
        live: true,
      };
    }
    return {
      ok: true,
      live: true,
      quote: {
        depositAddress: q.depositAddress,
        amountIn: q.amountIn ?? amountRaw,
        amountInUsd: q.amountInUsd ?? String(params.amountUsd),
        amountOut: q.amountOut ?? "",
        amountOutFormatted: q.amountOutFormatted ?? "",
        amountOutUsd: q.amountOutUsd ?? "",
        minAmountOut: q.minAmountOut ?? "",
        timeEstimate: q.timeEstimate ?? 60,
        deadline: q.deadline ?? deadline,
        refundFee: q.refundFee ?? "0",
        withdrawFee: q.withdrawFee ?? "0",
      },
    };
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : "1Click API unreachable",
      live: true,
    };
  }
}

export type DepositStatus =
  | "PENDING_DEPOSIT"
  | "KNOWN_DEPOSIT_TX"
  | "PROCESSING"
  | "SUCCESS"
  | "INCOMPLETE_DEPOSIT"
  | "REFUNDED"
  | "FAILED";

export type StatusResult = { ok: true; status: DepositStatus } | { ok: false; error: string };

/** Poll swap progress for a quote's deposit address. */
export async function getDepositStatus(depositAddress: string): Promise<StatusResult> {
  try {
    const res = await fetch(
      `${ONECLICK}/status?depositAddress=${encodeURIComponent(depositAddress)}`,
      { signal: AbortSignal.timeout(10_000) },
    );
    const data = (await res.json()) as { status?: string; message?: string };
    if (!res.ok || !data.status) {
      return { ok: false, error: data.message ?? `status failed (HTTP ${res.status})` };
    }
    return { ok: true, status: data.status as DepositStatus };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : "status unreachable" };
  }
}
