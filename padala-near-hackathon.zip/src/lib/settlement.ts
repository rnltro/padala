/**
 * Shared settlement flow: policy check -> live 1Click quote -> PENDING_DEPOSIT payment.
 *
 * Used by two callers:
 *   - POST /api/invoices/[id]/pay   (human clicks "Pay from agent")
 *   - GET  /api/cron/settle         (Autopilot — the agent itself, zero clicks)
 *
 * The audit trail records WHO triggered each step (actor + `trigger`), so a
 * human payment and an autonomous one look identical apart from the label.
 */

import { db } from "@/lib/db";
import { ACTORS, recordAudit } from "@/lib/audit";
import { evaluatePolicy } from "@/lib/policy";
import { getUsdcToNearQuote, getSourceChain } from "@/lib/intents";
import { ensurePolicy, settledTodayUsd, treasuryBalanceUsdc } from "@/lib/treasury";

export type SettlementSuccess = {
  ok: true;
  payment: { id: string; status: string; depositAddress: string; amountInUsd: number } & Record<string, unknown>;
  decision: Record<string, unknown>;
  quote: Record<string, unknown>;
};

export type SettlementFailure = {
  ok: false;
  status: number;
  error: string;
  decision?: Record<string, unknown>;
};

export async function initiateSettlement(params: {
  invoiceId: string;
  chainId: string;
  /** "human" (pay button) or "autopilot" (cron agent) — recorded in the audit trail. */
  trigger?: "human" | "autopilot";
}): Promise<SettlementSuccess | SettlementFailure> {
  const { invoiceId, chainId, trigger = "human" } = params;
  try {
    const chain = getSourceChain(chainId);
    if (!chain) {
      return { ok: false, status: 400, error: `Unsupported chain: ${chainId} (base, eth, arb, sol)` };
    }

    const invoice = await db.invoice.findUnique({ where: { id: invoiceId }, include: { payments: true } });
    if (!invoice) return { ok: false, status: 404, error: "Invoice not found" };
    if (invoice.status === "PAID") return { ok: false, status: 409, error: "Invoice is already paid" };

    const policy = await ensurePolicy();
    const [spentToday, balance] = await Promise.all([settledTodayUsd(), treasuryBalanceUsdc()]);

    const decision = evaluatePolicy({
      policy: {
        enabled: policy.enabled,
        perTxLimitUsd: policy.perTxLimitUsd,
        dailyLimitUsd: policy.dailyLimitUsd,
        autoApproveUnderUsd: policy.autoApproveUnderUsd,
        allowedChains: policy.allowedChains,
        allowedRecipients: policy.allowedRecipients,
      },
      amountUsd: invoice.amountUsd,
      sourceChain: chain.id,
      recipient: invoice.freelancerAccount,
      spentTodayUsd: spentToday,
      treasuryUsdc: balance,
    });

    await recordAudit(db, {
      type: decision.allowed ? "POLICY_CHECK" : "POLICY_BLOCK",
      actor: ACTORS.agent,
      invoiceRef: invoice.reference,
      summary: decision.allowed
        ? `Policy ${decision.mode} for $${invoice.amountUsd.toFixed(2)} via ${chain.label} — ${decision.checks.filter((c) => c.passed).length}/6 checks green${trigger === "autopilot" ? " (autopilot)" : ""}`
        : `Payment BLOCKED for $${invoice.amountUsd.toFixed(2)} via ${chain.label} — ${decision.blockedReasons.join("; ")}`,
      detail: { mode: decision.mode, checks: decision.checks, chainId: chain.id, trigger },
    });

    if (!decision.allowed) {
      return { ok: false, status: 403, error: "Blocked by spending policy", decision };
    }

    // Failed swaps refund to the invoice's MPC-derived address when available.
    const refundTo = invoice.refundAddress ?? chain.refundTo;

    const quote = await getUsdcToNearQuote({
      chainId: chain.id,
      amountUsd: invoice.amountUsd,
      recipient: invoice.freelancerAccount,
      refundTo: refundTo,
    });
    if (!quote.ok) {
      await recordAudit(db, {
        type: "QUOTE_FAILED",
        actor: ACTORS.agent,
        invoiceRef: invoice.reference,
        summary: `1Click quote failed on ${chain.label}: ${quote.error}`,
        detail: { chainId: chain.id, error: quote.error, trigger },
      });
      return { ok: false, status: 502, error: `Quote failed: ${quote.error}` };
    }

    await recordAudit(db, {
      type: "QUOTE_REQUESTED",
      actor: ACTORS.agent,
      invoiceRef: invoice.reference,
      summary: `1Click quote: ${Number(quote.quote.amountInUsd || 0).toFixed(2)} USD in → ${quote.quote.amountOutFormatted} USDC out on NEAR, ~${quote.quote.timeEstimate}s settle`,
      detail: {
        originAsset: chain.assetId,
        destinationAsset: "USDC on NEAR (nep141)",
        minAmountOut: quote.quote.minAmountOut,
        depositAddress: quote.quote.depositAddress,
        refundTo,
        refundSource: invoice.refundAddress ? "chain-signatures (MPC-derived)" : "fallback wallet",
        trigger,
      },
    });

    const payment = await db.payment.create({
      data: {
        invoiceId: invoice.id,
        sourceChain: chain.id,
        sourceAsset: chain.assetId,
        amountInUsd: invoice.amountUsd,
        amountOut: quote.quote.amountOut || null,
        amountOutUsd: quote.quote.amountOutUsd ? Number(quote.quote.amountOutUsd) : null,
        depositAddress: quote.quote.depositAddress,
        quoteDeadline: new Date(quote.quote.deadline),
        timeEstimate: quote.quote.timeEstimate,
        status: "PENDING_DEPOSIT",
      },
    });

    await recordAudit(db, {
      type: "PAYMENT_INITIATED",
      actor: ACTORS.agent,
      invoiceRef: invoice.reference,
      summary: `Deposit requested — send ${Number(quote.quote.amountInUsd || 0).toFixed(2)} USD in USDC (${chain.label}) to ${quote.quote.depositAddress}`,
      detail: {
        paymentId: payment.id,
        depositAddress: quote.quote.depositAddress,
        recipient: invoice.freelancerAccount,
        refundTo,
        mode: decision.mode,
        trigger,
      },
    });

    return { ok: true, payment, decision, quote: quote.quote };
  } catch (err) {
    return {
      ok: false,
      status: 500,
      error: err instanceof Error ? err.message : "Settlement failed",
    };
  }
}

/**
 * Route fee in basis points from a quote's raw amounts: (1 - out/in) * 10_000.
 * Returns null when the quote lacks usable raw amounts.
 */
export function quoteFeeBps(amountIn: string, amountOut: string): number | null {
  try {
    const inRaw = BigInt(amountIn);
    const outRaw = BigInt(amountOut);
    if (inRaw <= 0n || outRaw <= 0n) return null;
    if (outRaw >= inRaw) return 0; // quoted out >= in: zero/negative route fee
    return Math.round((Number(inRaw - outRaw) / Number(inRaw)) * 10_000);
  } catch {
    return null;
  }
}
