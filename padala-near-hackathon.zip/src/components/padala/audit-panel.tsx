"use client";

import { FileText, RefreshCw, ScrollText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { AuditEvent } from "./types";
import { timeAgo } from "./types";

const TYPE_STYLES: Record<string, { className: string; label: string }> = {
  POLICY_CHECK: { className: "bg-primary/15 text-primary border-primary/30", label: "POLICY PASS" },
  POLICY_BLOCK: { className: "bg-red-500/15 text-red-400 border-red-500/30", label: "POLICY BLOCK" },
  POLICY_UPDATED: { className: "bg-amber-500/15 text-amber-400 border-amber-500/30", label: "POLICY UPDATED" },
  PAYMENT_INITIATED: { className: "bg-muted text-muted-foreground border-border", label: "PAYMENT INITIATED" },
  PAYMENT_SETTLED: { className: "bg-primary/15 text-primary border-primary/30", label: "SETTLED (LIVE)" },
  PAYMENT_SETTLED_SIMULATED: { className: "bg-primary/10 text-primary/80 border-primary/20", label: "SETTLED (DEMO)" },
  QUOTE_REQUESTED: { className: "bg-muted text-muted-foreground border-border", label: "QUOTE" },
  QUOTE_FAILED: { className: "bg-red-500/15 text-red-400 border-red-500/30", label: "QUOTE FAILED" },
  INVOICE_CREATED: { className: "bg-muted text-muted-foreground border-border", label: "INVOICE" },
};

export function AuditPanel({ events, onRefresh }: { events: AuditEvent[]; onRefresh: () => void }) {
  return (
    <Card>
      <CardContent className="p-0">
        <div className="flex items-center justify-between border-b px-5 py-4">
          <div className="flex items-center gap-2">
            <ScrollText className="h-4 w-4 text-primary" />
            <h2 className="font-semibold">Audit trail</h2>
            <span className="text-sm text-muted-foreground">append-only · {events.length} events</span>
          </div>
          <Button variant="outline" size="sm" onClick={onRefresh}>
            <RefreshCw className="h-3.5 w-3.5" /> Refresh
          </Button>
        </div>
        <div className="scroll-slim max-h-[560px] overflow-y-auto">
          {events.length === 0 && (
            <p className="py-12 text-center text-muted-foreground">No events yet.</p>
          )}
          {events.map((e) => {
            const style = TYPE_STYLES[e.type] ?? { className: "bg-muted text-muted-foreground border-border", label: e.type };
            let detailPretty: string | null = null;
            try {
              const parsed = JSON.parse(e.detail);
              detailPretty = Object.keys(parsed).length ? JSON.stringify(parsed, null, 2) : null;
            } catch {
              detailPretty = e.detail && e.detail !== "{}" ? e.detail : null;
            }
            return (
              <div key={e.id} className="border-b px-5 py-4 last:border-b-0 hover:bg-card/60">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="outline" className={`${style.className} text-[11px] font-semibold tracking-wide`}>{style.label}</Badge>
                  {e.invoiceRef && (
                    <span className="flex items-center gap-1 font-mono text-xs text-muted-foreground">
                      <FileText className="h-3 w-3" /> {e.invoiceRef}
                    </span>
                  )}
                  <span className="ml-auto text-xs text-muted-foreground">{timeAgo(e.createdAt)}</span>
                </div>
                <p className="mt-1.5 text-sm">{e.summary}</p>
                <p className="mt-0.5 text-xs text-muted-foreground">actor: <span className="font-mono">{e.actor}</span></p>
                {detailPretty && (
                  <details className="mt-2">
                    <summary className="cursor-pointer text-xs text-muted-foreground hover:text-foreground">details</summary>
                    <pre className="scroll-slim mt-1.5 max-h-40 overflow-auto rounded-md border bg-background/70 p-3 font-mono text-[11px] leading-relaxed text-muted-foreground">
                      {detailPretty}
                    </pre>
                  </details>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
