"use client";

import { useEffect, useState } from "react";
import { AlertTriangle, Bot, Gauge, Loader2, PiggyBank, Save, ShieldOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import type { ChainInfo, Policy, Treasury } from "./types";
import { usd } from "./types";

/** Shape of GET /api/health — see src/app/api/health/route.ts. */
type HealthReport = {
  ok: boolean;
  uptimeSec: number;
  databaseUrlSet: boolean;
  databaseOk: boolean;
  code: string | null;
  error: string | null;
  diagnosis: string;
  fix: { windows: string[]; unix: string[] } | null;
};

export function TreasuryPanel({
  treasury,
  policy,
  chains,
  onDataChanged,
  loaded = true,
}: {
  treasury: Treasury | null;
  policy: Policy | null;
  chains: ChainInfo[];
  onDataChanged: () => void;
  /** true once the first data load finished — lets us show an error instead of spinning forever. */
  loaded?: boolean;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [draft, setDraft] = useState<Policy | null>(policy);
  // Self-diagnosis from /api/health (works even when the db layer is broken).
  const [health, setHealth] = useState<HealthReport | null>(null);

  useEffect(() => {
    if (policy && !draft) setDraft(policy);
  }, [policy, draft]);

  // Keep the form in sync when the policy changes elsewhere (e.g. initial load).
  useEffect(() => {
    setDraft(policy);
  }, [policy?.updatedAt]);

  // When the treasury fails to load, ask /api/health exactly why.
  useEffect(() => {
    if (!loaded || treasury) return;
    let cancelled = false;
    fetch("/api/health")
      .then((r) => r.json())
      .then((d) => {
        if (!cancelled) setHealth(d);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [loaded, treasury]);

  if (!treasury || !draft) {
    // Data load finished but the API returned nothing useful — /api/health names
    // the exact cause (skipped setup step, stale server on the port, …).
    if (loaded) {
      const minutes = health ? Math.floor(health.uptimeSec / 60) : null;
      return (
        <Card className="border-amber-500/40">
          <CardContent className="flex flex-col gap-3 py-10 text-center">
            <AlertTriangle className="mx-auto h-8 w-8 text-amber-400" />
            <p className="font-semibold text-foreground">Agent treasury could not load</p>

            {health ? (
              <div className="mx-auto flex max-w-xl flex-col gap-2 text-left">
                <p className="rounded-md border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-sm text-foreground">
                  <span className="font-semibold">Diagnosis:</span> {health.diagnosis}
                </p>
                {health.code || health.error ? (
                  <pre className="scroll-slim max-h-28 overflow-auto rounded-md border bg-muted/50 px-3 py-2 font-mono text-[11px] text-muted-foreground">
{[health.code, health.error].filter(Boolean).join("\n")}
                  </pre>
                ) : null}
                {health.fix ? (
                  <pre className="scroll-slim overflow-x-auto rounded-md border bg-muted/50 px-3 py-2 font-mono text-xs text-foreground">
{`# Windows (PowerShell)\n${health.fix.windows.join("\n")}\n\n# mac / linux\n${health.fix.unix.join("\n")}`}
                  </pre>
                ) : null}
                <p className="text-xs text-muted-foreground">
                  Server process up for <b>{minutes ?? "?"} min</b> — if that number did <i>not</i> reset after you
                  restarted <code>bun run dev</code>, an old server still owns port 3000 (Next likely moved the new one to
                  3001 — check the port in the terminal) or the fix ran in a different folder than <code>package.json</code>.
                </p>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Running self-diagnosis (api/health)…</p>
            )}

            <div className="mx-auto">
              <Button variant="outline" size="sm" onClick={onDataChanged}>
                <Loader2 className="h-3.5 w-3.5" /> Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      );
    }
    return (
      <div className="flex items-center justify-center py-24 text-muted-foreground">
        <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Loading treasury…
      </div>
    );
  }

  const spentPct = Math.min(100, treasury.dailyLimitUsd > 0 ? (treasury.spentTodayUsd / treasury.dailyLimitUsd) * 100 : 0);

  async function savePolicy() {
    setSaving(true);
    try {
      const res = await fetch("/api/policy", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          enabled: draft!.enabled,
          perTxLimitUsd: draft!.perTxLimitUsd,
          dailyLimitUsd: draft!.dailyLimitUsd,
          autoApproveUnderUsd: draft!.autoApproveUnderUsd,
          allowedChains: draft!.allowedChains.split(",").map((s) => s.trim()).filter(Boolean),
          allowedRecipients: draft!.allowedRecipients,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Save failed");
      toast({ title: "Policy saved", description: "The agent enforces it on the next payment — change logged to the audit trail." });
      onDataChanged();
    } catch (err) {
      toast({ title: "Could not save policy", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  function toggleChain(id: string) {
    const list = draft!.allowedChains.split(",").map((s) => s.trim()).filter(Boolean);
    const next = list.includes(id) ? list.filter((c) => c !== id) : [...list, id];
    setDraft({ ...draft!, allowedChains: next.join(",") });
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_420px]">
      {/* Agent wallet */}
      <div className="space-y-6">
        <Card className="border-primary/25">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bot className="h-5 w-5 text-primary" /> {treasury.agent.account}
              <Badge variant="outline" className={treasury.policyEnabled ? "border-primary/40 text-primary" : "border-red-500/40 text-red-400"}>
                {treasury.policyEnabled ? "AGENT ACTIVE" : "AGENT PAUSED"}
              </Badge>
            </CardTitle>
            <CardDescription>{treasury.agent.description} · {treasury.agent.network}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-sm text-muted-foreground">USDC on NEAR (Intents balance)</p>
                <p className="text-4xl font-bold tabular-nums text-primary text-glow">{usd(treasury.balanceUsdc)}</p>
              </div>
              <PiggyBank className="h-8 w-8 text-primary/40" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">Spent today (UTC)</span>
                <span className="font-medium tabular-nums">{usd(treasury.spentTodayUsd)} / {usd(treasury.dailyLimitUsd)}</span>
              </div>
              <Progress value={spentPct} className="h-2" />
              <p className="text-xs text-muted-foreground">Remaining today: {usd(treasury.remainingTodayUsd)} · per-tx limit {usd(treasury.perTxLimitUsd)}</p>
            </div>

            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-lg border p-3">
                <p className="text-muted-foreground">Payments in flight</p>
                <p className="text-xl font-semibold tabular-nums">{treasury.pendingPayments}</p>
              </div>
              <div className="rounded-lg border p-3">
                <p className="text-muted-foreground">Invoices settled</p>
                <p className="text-xl font-semibold tabular-nums">{treasury.invoicesPaid}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Gauge className="h-4 w-4 text-primary" /> How enforcement works
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-muted-foreground">
            <p>
              Every payment request is evaluated by the policy engine <span className="text-foreground">before</span> a quote is
              requested. Failed checks block the payment, and both the attempt and the decision land in the append-only audit trail.
            </p>
            <p>
              In production the same checks run inside a <span className="text-foreground">Shade Agent</span> (TEE-verified, running
              on Phala Cloud) and the treasury key lives behind <span className="text-foreground">NEAR Chain Signatures</span> — so
              the employer can hand the agent a wallet without handing over the keys. This demo enforces the identical rules at the
              API layer.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Policy editor */}
      <Card className="h-fit">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Spending policy
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{draft.enabled ? "active" : "paused"}</span>
              <Switch checked={draft.enabled} onCheckedChange={(v) => setDraft({ ...draft, enabled: v })} aria-label="Enable agent" />
            </div>
          </CardTitle>
          <CardDescription>{draft.enabled ? "Agent may move funds within these limits." : <span className="flex items-center gap-1 text-red-400"><ShieldOff className="h-3 w-3" /> All payments blocked while paused.</span>}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="perTx">Per-tx limit (USD)</Label>
              <Input id="perTx" type="number" min="1" value={draft.perTxLimitUsd} onChange={(e) => setDraft({ ...draft, perTxLimitUsd: Number(e.target.value) })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="daily">Daily cap (USD)</Label>
              <Input id="daily" type="number" min="1" value={draft.dailyLimitUsd} onChange={(e) => setDraft({ ...draft, dailyLimitUsd: Number(e.target.value) })} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="auto">Auto-approve under (USD)</Label>
            <Input id="auto" type="number" min="0" value={draft.autoApproveUnderUsd} onChange={(e) => setDraft({ ...draft, autoApproveUnderUsd: Number(e.target.value) })} />
            <p className="text-xs text-muted-foreground">At or below this amount the agent pays instantly; above, it flags the payment for human sign-off (recorded in the audit trail).</p>
          </div>

          <div className="space-y-2">
            <Label>Allowed funding chains</Label>
            <div className="grid grid-cols-2 gap-2">
              {chains.map((c) => (
                <label key={c.id} className="flex cursor-pointer items-center gap-2 rounded-md border p-2.5 text-sm has-[[data-state=checked]]:border-primary/50 has-[[data-state=checked]]:bg-primary/5">
                  <Checkbox checked={draft.allowedChains.split(",").map((s) => s.trim()).includes(c.id)} onCheckedChange={() => toggleChain(c.id)} />
                  {c.label}
                </label>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="recipients">Approved payees (NEAR accounts, comma-separated)</Label>
            <Input id="recipients" placeholder="empty = any account allowed" value={draft.allowedRecipients} onChange={(e) => setDraft({ ...draft, allowedRecipients: e.target.value })} className="font-mono text-sm" />
            <p className="text-xs text-muted-foreground">Tip: set this to <span className="font-mono">maria.padala.near</span>, then try paying an invoice to a different account — it will be blocked and audited.</p>
          </div>

          <Button onClick={savePolicy} disabled={saving} className="w-full font-semibold">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {saving ? "Saving…" : "Save policy"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
