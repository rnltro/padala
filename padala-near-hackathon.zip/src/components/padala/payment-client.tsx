"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  BadgeCheck,
  CalendarDays,
  Check,
  CircleAlert,
  Copy,
  ExternalLink,
  Landmark,
  Loader2,
  RefreshCw,
  ShieldCheck,
} from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import type { ChainInfo, Decision, Invoice, Payment, Quote } from "./types";
import { shortAddr, usd } from "./types";

const TIMELINE = ["PENDING_DEPOSIT", "KNOWN_DEPOSIT_TX", "PROCESSING", "SUCCESS"];
const ACTIVE_STATUSES = new Set(["PENDING_DEPOSIT", "KNOWN_DEPOSIT_TX", "PROCESSING"]);
const POLL_MS = 5_000;

type Phase = "form" | "deposit" | "settled";

export function PaymentClient({ invoice }: { invoice: Invoice }) {
  const { toast } = useToast();
  const [chains, setChains] = useState<ChainInfo[]>([]);
  const [chainId, setChainId] = useState("base");
  const activeInitial = invoice.payments.find((p) => ACTIVE_STATUSES.has(p.status)) ?? null;
  const [phase, setPhase] = useState<Phase>(
    invoice.status === "PAID" ? "settled" : activeInitial ? "deposit" : "form",
  );
  const [payment, setPayment] = useState<Payment | null>(activeInitial);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [decision, setDecision] = useState<Decision | null>(null);
  const [blocked, setBlocked] = useState<string | null>(null);
  const [paying, setPaying] = useState(false);
  const [checking, setChecking] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    fetch("/api/chains")
      .then((r) => r.json())
      .then((d) => setChains(d.chains ?? []))
      .catch(() => {});
  }, []);

  const settledPayment = invoice.payments.find((p) => p.status === "SUCCESS") ?? null;

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }, []);

  const checkStatus = useCallback(
    async (paymentId: string, silent = true) => {
      if (!silent) setChecking(true);
      try {
        const res = await fetch(`/api/payments/${paymentId}/status`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error ?? "Status failed");
        const updated: Payment = data.payment;
        setPayment(updated);
        if (updated.status === "SUCCESS") {
          setPhase("settled");
          stopPolling();
          if (!silent) {
            toast({ title: "Payment confirmed", description: "USDC settled on NEAR via NEAR Intents." });
          }
        }
        return updated;
      } catch {
        return null;
      } finally {
        if (!silent) setChecking(false);
      }
    },
    [stopPolling, toast],
  );

  // Auto-poll while a deposit is pending — the page is the client's only UI,
  // so it must update itself.
  useEffect(() => {
    stopPolling();
    if (phase === "deposit" && payment && ACTIVE_STATUSES.has(payment.status)) {
      pollRef.current = setInterval(() => {
        void checkStatus(payment.id, true);
      }, POLL_MS);
    }
    return stopPolling;
  }, [phase, payment, checkStatus, stopPolling]);

  async function pay() {
    setPaying(true);
    setBlocked(null);
    setDecision(null);
    try {
      const res = await fetch(`/api/invoices/${invoice.id}/pay`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chainId }),
      });
      const data = await res.json();
      if (res.status === 403) {
        setDecision(data.decision ?? null);
        setBlocked(data.error ?? "Blocked by spending policy");
        return;
      }
      if (!res.ok) throw new Error(data.error ?? "Payment failed");
      setDecision(data.decision ?? null);
      setQuote(data.quote);
      setPayment(data.payment);
      setPhase("deposit");
    } catch (err) {
      toast({
        title: "Could not start payment",
        description: err instanceof Error ? err.message : "Unknown error",
        variant: "destructive",
      });
    } finally {
      setPaying(false);
    }
  }

  function copy(text: string, label: string) {
    navigator.clipboard?.writeText(text);
    toast({ title: `${label} copied` });
  }

  const activeQuote = quote;

  return (
    <main className="flex min-h-screen flex-col items-center bg-background px-4 py-10">
      {/* Header */}
      <div className="mb-8 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-[0_0_24px_rgba(0,236,151,0.25)]">
          <Landmark className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-lg font-bold leading-tight">Padala</h1>
          <p className="text-xs text-muted-foreground">Pay this invoice with USDC from any chain</p>
        </div>
      </div>

      <Card className="w-full max-w-md">
        <CardContent className="space-y-5 p-6">
          {/* Invoice summary */}
          <div>
            <div className="flex items-center justify-between">
              <span className="font-mono text-sm text-muted-foreground">{invoice.reference}</span>
              {invoice.status === "PAID" ? (
                <Badge variant="outline" className="border-primary/30 bg-primary/15 text-primary">PAID</Badge>
              ) : (
                <Badge variant="outline" className="border-amber-500/30 bg-amber-500/15 text-amber-400">AWAITING PAYMENT</Badge>
              )}
            </div>
            <p className="mt-4 text-4xl font-bold tabular-nums text-primary">{usd(invoice.amountUsd)}</p>
            <p className="mt-1 text-sm text-muted-foreground">{invoice.description}</p>
            <p className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
              <span>Billed to <span className="font-medium text-foreground/80">{invoice.clientName}</span></span>
              <span className="flex items-center gap-1">
                <CalendarDays className="h-3 w-3" /> due {new Date(invoice.dueDate).toLocaleDateString()}
              </span>
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Pays to <button className="inline-flex items-center gap-1 font-mono text-primary/90 hover:underline" onClick={() => copy(invoice.freelancerAccount, "NEAR account")}>
                {invoice.freelancerAccount} <Copy className="h-3 w-3" />
              </button>
            </p>
          </div>

          <Separator />

          {/* SETTLED */}
          {phase === "settled" && (
            <div className="space-y-3">
              <div className="rounded-lg border border-primary/40 bg-primary/10 p-4">
                <p className="flex items-center gap-2 font-semibold text-primary">
                  <BadgeCheck className="h-5 w-5" /> Invoice paid — thank you!
                </p>
                <p className="mt-2 text-sm text-muted-foreground">
                  {settledPayment?.amountOutUsd
                    ? `${settledPayment.amountOutUsd.toFixed(2)} USDC`
                    : usd(invoice.amountUsd)}{" "}
                  was delivered as native USDC to <span className="font-mono">{invoice.freelancerAccount}</span> on
                  NEAR{invoice.paidAt ? ` · ${new Date(invoice.paidAt).toLocaleString()}` : ""}.
                </p>
              </div>
              <p className="text-center text-xs text-muted-foreground">
                Settled through NEAR Intents — solvers competed, funds arrived in seconds.
              </p>
            </div>
          )}

          {/* FORM: pick a chain and pay */}
          {phase === "form" && (
            <div className="space-y-4">
              <p className="text-sm font-semibold">Pay with USDC from</p>
              <div className="grid grid-cols-2 gap-2">
                {chains.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setChainId(c.id)}
                    className={`rounded-lg border p-3 text-left transition-colors ${chainId === c.id ? "border-primary bg-primary/10" : "border-border hover:border-primary/40"}`}
                  >
                    <span className="block text-sm font-semibold">{c.label}</span>
                    <span className="block text-xs text-muted-foreground">{c.note}</span>
                  </button>
                ))}
                {chains.length === 0 && (
                  <div className="col-span-2 rounded-lg border border-dashed p-3 text-sm text-muted-foreground">
                    Loading supported chains…
                  </div>
                )}
              </div>

              <Button onClick={pay} disabled={paying || chains.length === 0} className="w-full font-semibold">
                {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
                {paying ? "Requesting quote…" : `Pay ${usd(invoice.amountUsd)} in USDC`}
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                Every quote passes the employer&apos;s policy-gated agent wallet before a deposit address is issued.
              </p>

              {blocked && decision && (
                <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4">
                  <p className="flex items-center gap-2 font-semibold text-red-400">
                    <CircleAlert className="h-4 w-4" /> {blocked}
                  </p>
                  <ul className="mt-2 space-y-1 text-sm text-red-300/90">
                    {decision.blockedReasons.map((r, i) => (
                      <li key={i}>· {r}</li>
                    ))}
                  </ul>
                  <p className="mt-2 text-xs text-muted-foreground">
                    Nothing moved. The attempt is recorded in the employer&apos;s audit trail.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* DEPOSIT: QR + address + live status */}
          {phase === "deposit" && payment && (
            <div className="space-y-4">
              <div className="rounded-lg border border-primary/30 bg-primary/5 p-4 space-y-3 text-sm">
                <p className="flex items-center justify-between">
                  <span className="text-muted-foreground">1Click quote (live)</span>
                  <Badge variant="outline" className="border-primary/40 text-primary">
                    ~{quote?.timeEstimate ?? payment.timeEstimate ?? 60}s
                  </Badge>
                </p>
                <p className="flex items-center justify-between">
                  <span className="text-muted-foreground">You send</span>
                  <span className="font-semibold">
                    {activeQuote
                      ? `${(Number(activeQuote.amountIn) / 1e6).toLocaleString("en-US", { maximumFractionDigits: 2 })} USDC`
                      : `${usd(payment.amountInUsd)} USDC`}{" "}
                    · {payment.sourceChain.toUpperCase()}
                  </span>
                </p>
                <p className="flex items-center justify-between">
                  <span className="text-muted-foreground">{invoice.clientName.split(" ")[0]} receives</span>
                  <span className="font-semibold text-primary">
                    {activeQuote?.amountOutFormatted ?? payment.amountOutUsd?.toFixed(2) ?? "—"} USDC on NEAR
                  </span>
                </p>

                <Separator />

                {/* QR */}
                <div className="flex flex-col items-center gap-3">
                  <div className="rounded-xl border bg-white p-3">
                    <QRCodeSVG value={payment.depositAddress} size={168} level="M" />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Scan with your wallet, or copy the deposit address:
                  </p>
                  <button
                    className="flex w-full items-center justify-between gap-2 rounded-md border bg-background/60 p-2 text-left font-mono text-xs hover:border-primary/40"
                    onClick={() => copy(payment.depositAddress, "Deposit address")}
                  >
                    <span className="truncate">{shortAddr(payment.depositAddress, 14, 10)}</span>
                    <Copy className="h-3.5 w-3.5 shrink-0" />
                  </button>
                </div>

                <p className="text-xs text-muted-foreground">
                  Send <span className="font-medium text-foreground/80">USDC on {payment.sourceChain.toUpperCase()}</span> to
                  this address — solvers settle automatically to {invoice.freelancerAccount}. This page updates itself.
                </p>
              </div>

              {/* Timeline */}
              <div className="flex items-center justify-between rounded-lg border p-3">
                {TIMELINE.map((s, i) => {
                  const currentIdx = TIMELINE.indexOf(payment.status);
                  const reached = currentIdx >= i && currentIdx !== -1;
                  return (
                    <div key={s} className="flex flex-1 items-center">
                      <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[10px] font-bold ${reached ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground"}`}>
                        {i + 1}
                      </div>
                      {i < TIMELINE.length - 1 && <div className={`h-px flex-1 ${currentIdx > i ? "bg-primary" : "bg-border"}`} />}
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <Loader2 className="h-3 w-3 animate-spin" /> watching for your deposit…
                </span>
                <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => checkStatus(payment.id, false)} disabled={checking}>
                  {checking ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />} check now
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <p className="mt-6 flex items-center gap-1.5 text-xs text-muted-foreground">
        Powered by <span className="font-medium text-foreground/80">NEAR Intents · 1Click API</span>
        <ExternalLink className="h-3 w-3" />
      </p>
    </main>
  );
}
