"use client";

import { useCallback, useEffect, useState } from "react";
import { Bot, Coins, Landmark, ShieldCheck, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { InvoicesPanel } from "./invoices-panel";
import { TreasuryPanel } from "./treasury-panel";
import { AuditPanel } from "./audit-panel";
import { ArchitecturePanel } from "./architecture-panel";
import type { AuditEvent, ChainInfo, Invoice, Policy, Treasury } from "./types";
import { usd } from "./types";

type Stats = {
  paymentsSettled: number;
  liveSettled: number;
  invoicesPaid: number;
  volumeUsd: number;
  avgSettleSec: number | null;
  avgCostBps: number | null;
  wire: { costUsd: number; days: string };
  savedVsWireUsd: number;
};

export function Dashboard() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [chains, setChains] = useState<ChainInfo[]>([]);
  const [treasury, setTreasury] = useState<Treasury | null>(null);
  const [policy, setPolicy] = useState<Policy | null>(null);
  const [audit, setAudit] = useState<AuditEvent[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loaded, setLoaded] = useState(false);

  const loadShared = useCallback(async () => {
    try {
      const [invRes, treRes, polRes, audRes, statsRes] = await Promise.all([
        fetch("/api/invoices"),
        fetch("/api/treasury"),
        fetch("/api/policy"),
        fetch("/api/audit?limit=200"),
        fetch("/api/stats"),
      ]);
      const [inv, tre, pol, aud, st] = await Promise.all([
        invRes.json(), treRes.json(), polRes.json(), audRes.json(), statsRes.json(),
      ]);
      setInvoices(inv.invoices ?? []);
      setTreasury(tre.agent ? tre : null);
      setPolicy(pol.policy ?? null);
      setAudit(aud.events ?? []);
      setStats(st.paymentsSettled !== undefined ? st : null);
    } catch {
      // Keep last-known state on transient errors.
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => {
    void loadShared();
    fetch("/api/chains")
      .then((r) => r.json())
      .then((d) => setChains(d.chains ?? []))
      .catch(() => {});
  }, [loadShared]);

  // Poll the audit trail lightly so the trail feels alive during a demo.
  useEffect(() => {
    const t = setInterval(() => {
      fetch("/api/audit?limit=200")
        .then((r) => r.json())
        .then((d) => setAudit(d.events ?? []))
        .catch(() => {});
    }, 15000);
    return () => clearInterval(t);
  }, []);

  const usd0 = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
  const statCards = treasury
    ? [
        { icon: Coins, label: "Treasury (USDC on NEAR)", value: usd(treasury.balanceUsdc), accent: true },
        { icon: TrendingUp, label: "Spent today (UTC)", value: usd(treasury.spentTodayUsd) },
        { icon: Landmark, label: "Invoices settled", value: String(treasury.invoicesPaid) },
        { icon: ShieldCheck, label: "Limits · tx / day", value: `${usd0(treasury.perTxLimitUsd)} / ${usd0(treasury.dailyLimitUsd)}` },
      ]
    : [];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="border-b bg-card/40">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-[0_0_24px_rgba(0,236,151,0.25)]">
              <Landmark className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight">Padala</h1>
              <p className="text-xs text-muted-foreground">Any-chain USDC in · native USDC on NEAR out · policy-gated agent in between</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-3 py-1 font-medium text-primary">
              <Bot className="h-3.5 w-3.5" /> NEAR HACKATHON — Real-World Money
            </span>
            <span className="rounded-full border border-amber-500/40 bg-amber-500/10 px-3 py-1 font-medium text-amber-400">
              AI Security &amp; Defense
            </span>
          </div>
        </div>
      </header>

      {/* Stats */}
      <section className="mx-auto w-full max-w-6xl px-4 pt-6 sm:px-6" aria-label="Treasury stats">
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {statCards.map((s) => (
            <Card key={s.label} className={s.accent ? "border-primary/25" : undefined}>
              <CardContent className="flex items-center gap-3 p-4">
                <s.icon className={`h-5 w-5 shrink-0 ${s.accent ? "text-primary" : "text-muted-foreground"}`} />
                <div className="min-w-0">
                  <p className="truncate text-xs text-muted-foreground">{s.label}</p>
                  <p className={`truncate text-lg font-bold tabular-nums ${s.accent ? "text-primary" : ""}`}>{loaded ? s.value : "—"}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Impact strip — fills in as settlements land */}
      {stats && stats.paymentsSettled > 0 && (
        <section className="mx-auto w-full max-w-6xl px-4 pt-3 sm:px-6" aria-label="Impact">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-1.5 rounded-lg border border-primary/20 bg-primary/5 px-4 py-2.5 text-xs text-muted-foreground">
            <span className="font-semibold text-primary">Impact</span>
            <span>settled volume <b className="text-foreground">{usd(stats.volumeUsd)}</b></span>
            <span>avg settle <b className="text-foreground">{stats.avgSettleSec ?? "—"}s</b></span>
            <span>avg all-in cost <b className="text-foreground">{stats.avgCostBps ?? "—"} bps</b> vs wire ${stats.wire.costUsd} + {stats.wire.days}</span>
            <span>wire fees saved <b className="text-foreground">{usd(stats.savedVsWireUsd)}</b></span>
          </div>
        </section>
      )}

      {/* Tabs */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-6 sm:px-6">
        <Tabs defaultValue="invoices" className="space-y-6">
          <TabsList className="flex w-full flex-wrap justify-start gap-1 sm:w-fit">
            <TabsTrigger value="invoices" className="gap-1.5">
              <Landmark className="h-3.5 w-3.5" /> Invoices
            </TabsTrigger>
            <TabsTrigger value="treasury" className="gap-1.5">
              <Bot className="h-3.5 w-3.5" /> Agent treasury &amp; policy
            </TabsTrigger>
            <TabsTrigger value="audit" className="gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5" /> Audit trail
            </TabsTrigger>
            <TabsTrigger value="architecture" className="gap-1.5">
              How it works
            </TabsTrigger>
          </TabsList>

          <TabsContent value="invoices">
            <InvoicesPanel invoices={invoices} chains={chains} policy={policy} onDataChanged={loadShared} />
          </TabsContent>

          <TabsContent value="treasury">
            <TreasuryPanel treasury={treasury} policy={policy} chains={chains} onDataChanged={loadShared} loaded={loaded} />
          </TabsContent>

          <TabsContent value="audit">
            <AuditPanel events={audit} onRefresh={loadShared} />
          </TabsContent>

          <TabsContent value="architecture">
            <ArchitecturePanel />
          </TabsContent>
        </Tabs>
      </main>

      {/* Sticky footer */}
      <footer className="mt-auto border-t bg-card/40">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-3 text-xs text-muted-foreground sm:px-6">
          <p>
            Padala — built for the <span className="font-medium text-foreground">NEAR HACKATHON</span> (Nov 1–14, 2026) · submissions close Nov 14, 23:59 UTC
          </p>
          <p className="font-mono">Powered by NEAR Intents · 1Click API · native USDC on NEAR</p>
        </div>
      </footer>
    </div>
  );
}
