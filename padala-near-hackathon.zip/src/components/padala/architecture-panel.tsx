"use client";

import { ArrowRight, Bot, CheckCircle2, CircleDot, Coins, Globe, ShieldCheck, Wallet } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const FLOW = [
  {
    icon: Bot,
    title: "1 · Employer's agent wallet",
    body: "The agent holds a policy, not a person's keys. Per-tx limits, daily caps, chain + payee allowlists are checked before anything moves.",
    tag: "Shade Agent (TEE) + Chain Signatures",
  },
  {
    icon: Globe,
    title: "2 · NEAR Intents — 1Click",
    body: "A live quote turns 'pay $1,800 of USDC' into one deposit address on the source chain. Solvers compete; settlement to NEAR takes ~20–45 seconds.",
    tag: "1Click API · live in this app",
  },
  {
    icon: Coins,
    title: "3 · Freelancer paid on NEAR",
    body: "Native USDC lands in the freelancer's NEAR Intents balance — same asset they invoice in, no bank, no 3–5 day wire, ~1% total cost.",
    tag: "nep141 USDC",
  },
];

const REAL = [
  "Live 1Click quotes with real per-swap deposit addresses (Base, Ethereum, Arbitrum, Solana → USDC on NEAR)",
  "Real deposit-status polling against the 1Click API — deposit real USDC and the invoice settles for real",
  "Policy engine + append-only audit trail enforced on every payment path (server-side, not just UI)",
];

const DEMO = [
  "Treasury balance is a fixed demo pool (12,500 USDC) — settled payments decrement it",
  "'Simulate settlement' button for judging: marks the swap SUCCESS without waiting for an on-chain deposit",
  "Agent wallet identity (agent.padala.near) is represented server-side; TEE deployment is the production step",
];

export function ArchitecturePanel() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 lg:grid-cols-3">
        {FLOW.map((step, i) => (
          <Card key={step.title} className="relative">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-base">
                <step.icon className="h-5 w-5 text-primary" /> {step.title}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-muted-foreground">{step.body}</p>
              <Badge variant="outline" className="border-primary/30 text-xs text-primary/90">{step.tag}</Badge>
              {i < FLOW.length - 1 && (
                <ArrowRight className="absolute -right-5 top-1/2 hidden h-5 w-5 -translate-y-1/2 text-muted-foreground lg:block" />
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <CheckCircle2 className="h-4 w-4 text-primary" /> What is real
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2.5 text-sm">
              {REAL.map((r) => (
                <li key={r} className="flex gap-2">
                  <CircleDot className="mt-0.5 h-3.5 w-3.5 shrink-0 text-primary" />
                  <span className="text-muted-foreground">{r}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-base">
              <Wallet className="h-4 w-4 text-amber-400" /> What is demo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2.5 text-sm">
              {DEMO.map((r) => (
                <li key={r} className="flex gap-2">
                  <CircleDot className="mt-0.5 h-3.5 w-3.5 shrink-0 text-amber-400" />
                  <span className="text-muted-foreground">{r}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <ShieldCheck className="h-4 w-4 text-primary" /> Tracks this hits
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Badge variant="outline" className="border-primary/40 text-primary">Real-World Money — payroll, invoices, stablecoin payments onchain</Badge>
          <Badge variant="outline" className="border-amber-500/40 text-amber-400">AI Security &amp; Defense — spending limits, wallet safeguards, audit trail for AI-controlled money</Badge>
        </CardContent>
      </Card>
    </div>
  );
}
