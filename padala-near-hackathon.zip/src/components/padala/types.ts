export type Payment = {
  id: string;
  invoiceId: string;
  sourceChain: string;
  sourceAsset: string;
  amountInUsd: number;
  amountOut: string | null;
  amountOutUsd: number | null;
  depositAddress: string;
  quoteDeadline: string | null;
  timeEstimate: number | null;
  status: string;
  simulated: boolean;
  createdAt: string;
  settledAt: string | null;
};

export type Invoice = {
  id: string;
  reference: string;
  clientName: string;
  description: string;
  amountUsd: number;
  status: "AWAITING_PAYMENT" | "PAID" | string;
  dueDate: string;
  freelancerAccount: string;
  /** MPC-derived EVM refund address (Chain Signatures) — null = fallback wallet. */
  refundAddress: string | null;
  refundPath: string | null;
  /** Autopilot: agent settles automatically when the route fee fits the budget. */
  autoSettle: boolean;
  maxFeeBps: number;
  autopilotChain: string;
  /** Batch payroll: label of the run that created this invoice (null = solo). */
  payrollRunLabel: string | null;
  createdAt: string;
  paidAt: string | null;
  payments: Payment[];
}

export type PayrollRun = {
  id: string;
  label: string;
  description: string;
  scheduledFor: string | null;
  autoSettle: boolean;
  maxFeeBps: number;
  lineCount: number;
  totalUsd: number;
  invoiceRefs: string;
  warnings: string;
  createdAt: string;
};

export type Policy = {
  id: string;
  enabled: boolean;
  perTxLimitUsd: number;
  dailyLimitUsd: number;
  autoApproveUnderUsd: number;
  allowedChains: string;
  allowedRecipients: string;
  updatedAt: string;
};

export type Treasury = {
  agent: { account: string; description: string; network: string };
  balanceUsdc: number;
  spentTodayUsd: number;
  remainingTodayUsd: number;
  dailyLimitUsd: number;
  perTxLimitUsd: number;
  policyEnabled: boolean;
  pendingPayments: number;
  invoicesPaid: number;
};

export type AuditEvent = {
  id: string;
  type: string;
  actor: string;
  summary: string;
  detail: string;
  invoiceRef: string | null;
  createdAt: string;
};

export type PolicyCheck = {
  name: string;
  label: string;
  passed: boolean;
  detail: string;
};

export type Decision = {
  allowed: boolean;
  mode: "AUTO_APPROVED" | "WITHIN_LIMITS" | "BLOCKED";
  checks: PolicyCheck[];
  blockedReasons: string[];
};

export type Quote = {
  depositAddress: string;
  amountIn: string;
  amountInUsd: string;
  amountOut: string;
  amountOutFormatted: string;
  amountOutUsd: string;
  minAmountOut: string;
  timeEstimate: number;
  deadline: string;
  refundFee: string;
  withdrawFee: string;
};

export type ChainInfo = { id: string; label: string; note: string };

export function usd(n: number | null | undefined): string {
  if (n === null || n === undefined || !Number.isFinite(n)) return "—";
  return n.toLocaleString("en-US", { style: "currency", currency: "USD" });
}

export function shortAddr(a: string, head = 6, tail = 4): string {
  if (a.length <= head + tail + 3) return a;
  return `${a.slice(0, head)}…${a.slice(-tail)}`;
}

export function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
