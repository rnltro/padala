"use client";

import { useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  Bot,
  CalendarDays,
  Check,
  CircleAlert,
  Copy,
  Download,
  Landmark,
  Layers,
  Link2,
  Loader2,
  Plus,
  RefreshCw,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { parsePayrollText, policyPreFlight } from "@/lib/invoicing";
import type { ChainInfo, Decision, Invoice, Payment, Policy, Quote } from "./types";
import { shortAddr, timeAgo, usd } from "./types";

type PayFlow = {
  payment: Payment | null;
  decision: Decision | null;
  quote: Quote | null;
  error: string | null;
  checking: boolean;
};

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    AWAITING_PAYMENT: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    PAID: "bg-primary/15 text-primary border-primary/30",
    PENDING_DEPOSIT: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    KNOWN_DEPOSIT_TX: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    PROCESSING: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    SUCCESS: "bg-primary/15 text-primary border-primary/30",
    REFUNDED: "bg-red-500/15 text-red-400 border-red-500/30",
    FAILED: "bg-red-500/15 text-red-400 border-red-500/30",
  };
  const label = status.replace(/_/g, " ");
  return (
    <Badge variant="outline" className={`${map[status] ?? "bg-muted text-muted-foreground border-border"} font-medium`}>
      {label}
    </Badge>
  );
}

const TIMELINE = ["PENDING_DEPOSIT", "KNOWN_DEPOSIT_TX", "PROCESSING", "SUCCESS"];

export function InvoicesPanel({
  invoices,
  chains,
  policy,
  onDataChanged,
}: {
  invoices: Invoice[];
  chains: ChainInfo[];
  policy: Policy | null;
  onDataChanged: () => void;
}) {
  const { toast } = useToast();
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({
    clientName: "",
    description: "",
    amountUsd: "",
    dueDate: "",
    freelancerAccount: "maria.padala.near",
  });
  const [autoSettle, setAutoSettle] = useState(false);
  const [maxFeePct, setMaxFeePct] = useState("1");
  const [togglingAutopilot, setTogglingAutopilot] = useState<string | null>(null);
  const [payInvoice, setPayInvoice] = useState<Invoice | null>(null);
  const [chainId, setChainId] = useState("base");
  const [paying, setPaying] = useState(false);
  const [flow, setFlow] = useState<PayFlow | null>(null);

  // ---- Batch payroll dialog state ----
  const [batchOpen, setBatchOpen] = useState(false);
  const [batchLabel, setBatchLabel] = useState("");
  const [batchText, setBatchText] = useState("");
  const [batchScheduledFor, setBatchScheduledFor] = useState("");
  const [batchAutoSettle, setBatchAutoSettle] = useState(false);
  const [batchMaxFeePct, setBatchMaxFeePct] = useState("1");
  const [creatingRun, setCreatingRun] = useState(false);
  const [serverLineErrors, setServerLineErrors] = useState<{ line: number; error: string }[]>([]);

  async function createInvoice() {
    const amount = Number(form.amountUsd);
    if (!form.clientName.trim() || !form.description.trim() || !Number.isFinite(amount) || amount <= 0 || !form.dueDate) {
      toast({ title: "Missing fields", description: "Client, description, amount and due date are required.", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const res = await fetch("/api/invoices", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          clientName: form.clientName,
          description: form.description,
          amountUsd: amount,
          dueDate: new Date(form.dueDate).toISOString(),
          freelancerAccount: form.freelancerAccount,
          autoSettle,
          maxFeeBps: Math.round(Number(maxFeePct) * 100) || 100,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Failed to create invoice");
      toast({
        title: `Invoice ${data.invoice.reference} created`,
        description: `${form.clientName} owes ${usd(amount)}${autoSettle ? " · autopilot armed" : ""}.`,
      });
      setForm({ clientName: "", description: "", amountUsd: "", dueDate: "", freelancerAccount: form.freelancerAccount });
      setAutoSettle(false);
      onDataChanged();
    } catch (err) {
      toast({ title: "Could not create invoice", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  }

  function openPayDialog(invoice: Invoice) {
    setPayInvoice(invoice);
    setChainId("base");
    setFlow(null);
  }

  async function payInvoiceAction() {
    if (!payInvoice) return;
    setPaying(true);
    setFlow(null);
    try {
      const res = await fetch(`/api/invoices/${payInvoice.id}/pay`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chainId }),
      });
      const data = await res.json();
      if (res.status === 403) {
        setFlow({ payment: null, decision: data.decision, quote: null, error: data.error ?? "Blocked by spending policy", checking: false });
        onDataChanged();
        return;
      }
      if (!res.ok) throw new Error(data.error ?? "Payment failed");
      setFlow({ payment: data.payment, decision: data.decision, quote: data.quote, error: null, checking: false });
      onDataChanged();
      toast({
        title: `Quote live — ${data.quote.timeEstimate}s to settle`,
        description: `Send USDC on ${chainId.toUpperCase()} to the deposit address to settle for real.`,
      });
    } catch (err) {
      toast({ title: "Payment failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    } finally {
      setPaying(false);
    }
  }

  async function simulateSettlement(paymentId: string) {
    setFlow((f) => (f ? { ...f, checking: true } : f));
    try {
      const res = await fetch(`/api/payments/${paymentId}/simulate`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Simulate failed");
      setFlow((f) => (f ? { ...f, payment: data.payment, checking: false } : f));
      toast({ title: "Settled (demo)", description: "USDC credited to the freelancer's NEAR Intents balance." });
      onDataChanged();
      if (payInvoice) {
        const refreshed = await fetch("/api/invoices").then((r) => r.json());
        const updated = (refreshed.invoices as Invoice[]).find((i) => i.id === payInvoice.id);
        if (updated) setPayInvoice(updated);
      }
    } catch (err) {
      toast({ title: "Simulate failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
      setFlow((f) => (f ? { ...f, checking: false } : f));
    }
  }

  async function checkLiveStatus(paymentId: string) {
    setFlow((f) => (f ? { ...f, checking: true } : f));
    try {
      const res = await fetch(`/api/payments/${paymentId}/status`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Status failed");
      setFlow((f) => (f ? { ...f, payment: data.payment, checking: false } : f));
      if (data.payment?.status === "SUCCESS") {
        toast({ title: "Live settlement confirmed", description: "1Click reported SUCCESS." });
        onDataChanged();
      } else {
        toast({ title: `Live status: ${data.payment?.status.replace(/_/g, " ")}`, description: data.pollError ?? undefined });
      }
    } catch (err) {
      toast({ title: "Status check failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
      setFlow((f) => (f ? { ...f, checking: false } : f));
    }
  }

  function copy(text: string, label: string) {
    navigator.clipboard?.writeText(text);
    toast({ title: `${label} copied` });
  }

  async function toggleAutopilot(invoice: Invoice) {
    setTogglingAutopilot(invoice.id);
    try {
      const res = await fetch(`/api/invoices/${invoice.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ autoSettle: !invoice.autoSettle }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Toggle failed");
      toast({
        title: data.invoice.autoSettle ? "Autopilot armed" : "Autopilot off",
        description: data.invoice.autoSettle
          ? `The agent can now settle ${invoice.reference} on its own when the fee fits.`
          : "Back to manual payments only.",
      });
      onDataChanged();
    } catch (err) {
      toast({ title: "Could not update autopilot", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    } finally {
      setTogglingAutopilot(null);
    }
  }

  const awaiting = invoices.filter((i) => i.status === "AWAITING_PAYMENT");

  // ---- Batch payroll: live paste preview (parse + total + pre-flight) ----
  const parsed = parsePayrollText(batchText);
  const batchTotal = parsed.lines.reduce((s, l) => s + l.amountUsd, 0);
  const preFlight =
    parsed.lines.length > 0 && policy
      ? policyPreFlight(parsed.lines, { perTxLimitUsd: policy.perTxLimitUsd, dailyLimitUsd: policy.dailyLimitUsd })
      : [];
  const batchReady = batchLabel.trim().length > 0 && parsed.lines.length > 0 && parsed.errors.length === 0;

  function openBatchDialog() {
    setBatchOpen(true);
    setServerLineErrors([]);
  }

  async function createPayrollRun() {
    if (!batchReady) return;
    setCreatingRun(true);
    setServerLineErrors([]);
    try {
      const res = await fetch("/api/payroll-runs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          label: batchLabel,
          scheduledFor: batchScheduledFor || undefined,
          autoSettle: batchAutoSettle,
          maxFeeBps: Math.round(Number(batchMaxFeePct) * 100) || 100,
          lines: parsed.lines,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setServerLineErrors(data.lineErrors ?? []);
        throw new Error(data.error ?? "Failed to create payroll run");
      }
      toast({
        title: `Payroll run "${data.run.label}" created`,
        description: `${data.run.lineCount} invoices · ${usd(data.run.totalUsd)} total${data.warnings?.length ? " · policy warnings — see audit trail" : " · all within policy"}`,
      });
      setBatchOpen(false);
      setBatchLabel("");
      setBatchText("");
      setBatchScheduledFor("");
      setBatchAutoSettle(false);
      onDataChanged();
    } catch (err) {
      toast({ title: "Payroll run failed", description: err instanceof Error ? err.message : "Unknown error", variant: "destructive" });
    } finally {
      setCreatingRun(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[380px_1fr]">
      {/* New invoice */}
      <Card className="h-fit">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Plus className="h-4 w-4 text-primary" /> New invoice
          </CardTitle>
          <CardDescription>Bill in USD, get paid in USDC on NEAR.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="client">Client</Label>
            <Input id="client" placeholder="Acme Studio" value={form.clientName} onChange={(e) => setForm({ ...form, clientName: e.target.value })} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="desc">Work description</Label>
            <Textarea id="desc" placeholder="Landing page design + build" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount (USD)</Label>
              <Input id="amount" type="number" min="1" step="0.01" placeholder="1450" value={form.amountUsd} onChange={(e) => setForm({ ...form, amountUsd: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="due">Due date</Label>
              <Input id="due" type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="freelancer">Your NEAR account (receives USDC)</Label>
            <Input id="freelancer" placeholder="maria.padala.near" value={form.freelancerAccount} onChange={(e) => setForm({ ...form, freelancerAccount: e.target.value })} className="font-mono text-sm" />
            <p className="text-xs text-muted-foreground">Funds land as native USDC in your NEAR Intents balance.</p>
          </div>
          <div className="rounded-lg border bg-card/60 p-3 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="flex items-center gap-1.5 text-sm font-medium">
                  <Bot className="h-4 w-4 text-primary" /> Autopilot
                </p>
                <p className="text-xs text-muted-foreground">Agent settles this invoice on its own when the route fee fits.</p>
              </div>
              <Switch checked={autoSettle} onCheckedChange={setAutoSettle} aria-label="Toggle autopilot" />
            </div>
            {autoSettle && (
              <div className="space-y-1.5">
                <Label htmlFor="maxfee" className="text-xs">Max route fee (%)</Label>
                <Input id="maxfee" type="number" min="0.01" max="10" step="0.01" value={maxFeePct} onChange={(e) => setMaxFeePct(e.target.value)} className="h-8" />
                <p className="text-xs text-muted-foreground">Agent re-quotes every 2 min and only executes ≤ budget. Never overpays.</p>
              </div>
            )}
          </div>
          <Button onClick={createInvoice} disabled={creating} className="w-full font-semibold">
            {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            {creating ? "Creating…" : "Create invoice"}
          </Button>
        </CardContent>
      </Card>

      {/* Invoice list */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-lg font-semibold">
            Invoices <span className="ml-1 text-sm font-normal text-muted-foreground">{awaiting.length} awaiting payment</span>
          </h2>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" className="gap-1.5" onClick={openBatchDialog}>
              <Layers className="h-3.5 w-3.5 text-primary" /> Batch payroll
            </Button>
            <Button variant="outline" size="sm" className="gap-1.5" asChild>
              <a href="/api/invoices/export" title="Download the invoice ledger as CSV">
                <Download className="h-3.5 w-3.5" /> Export CSV
              </a>
            </Button>
          </div>
        </div>
        {invoices.length === 0 && (
          <Card className="border-dashed">
            <CardContent className="flex flex-col items-center gap-2 py-10 text-center text-muted-foreground">
              <Landmark className="h-8 w-8 opacity-40" />
              <p>No invoices yet — create your first one on the left.</p>
            </CardContent>
          </Card>
        )}
        {invoices.map((inv) => {
          const latest = inv.payments[0];
          return (
            <Card key={inv.id} className="transition-colors hover:border-primary/40">
              <CardContent className="p-5">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-sm text-muted-foreground">{inv.reference}</span>
                      <StatusBadge status={inv.status} />
                      {inv.autoSettle && inv.status === "AWAITING_PAYMENT" && (
                        <Badge variant="outline" className="border-primary/40 text-xs text-primary">
                          <Bot className="mr-1 h-3 w-3" /> autopilot ≤{(inv.maxFeeBps / 100).toFixed(2)}%
                        </Badge>
                      )}
                      {latest?.simulated && inv.status === "PAID" && (
                        <Badge variant="outline" className="border-border text-xs text-muted-foreground">demo settlement</Badge>
                      )}
                      {inv.payrollRunLabel && (
                        <Badge variant="outline" className="border-violet-500/40 text-xs text-violet-300" title={`Created by payroll run "${inv.payrollRunLabel}"`}>
                          <Layers className="mr-1 h-3 w-3" /> {inv.payrollRunLabel}
                        </Badge>
                      )}
                    </div>
                    <p className="truncate font-semibold">{inv.clientName}</p>
                    <p className="text-sm text-muted-foreground">{inv.description}</p>
                    <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                      <CalendarDays className="h-3 w-3" /> due {new Date(inv.dueDate).toLocaleDateString()} · pays to
                      <button className="inline-flex items-center gap-1 font-mono text-primary/90 hover:underline" onClick={() => copy(inv.freelancerAccount, "NEAR account")}>
                        {inv.freelancerAccount} <Copy className="h-3 w-3" />
                      </button>
                    </p>
                    {inv.refundAddress && (
                      <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                        <ShieldCheck className="h-3 w-3 text-primary" /> refunds →
                        <button className="inline-flex items-center gap-1 font-mono text-primary/90 hover:underline" onClick={() => copy(inv.refundAddress!, "Refund address")} title={`MPC-derived via "${inv.refundPath}" — key never exists anywhere`}>
                          {shortAddr(inv.refundAddress)} <Copy className="h-3 w-3" />
                        </button>
                        <span className="text-[10px] uppercase tracking-wide">chain signatures</span>
                      </p>
                    )}
                  </div>
                  <div className="flex flex-col items-end gap-3">
                    <div className="text-2xl font-bold tabular-nums text-primary">{usd(inv.amountUsd)}</div>
                    {inv.status === "AWAITING_PAYMENT" ? (
                      <div className="flex flex-col items-end gap-1.5">
                        <Button size="sm" className="font-semibold" onClick={() => openPayDialog(inv)}>
                          Pay from agent <ArrowRight className="h-3.5 w-3.5" />
                        </Button>
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            className={`h-7 gap-1 px-2 text-xs ${inv.autoSettle ? "text-primary" : "text-muted-foreground"}`}
                            onClick={() => toggleAutopilot(inv)}
                            disabled={togglingAutopilot === inv.id}
                          >
                            {togglingAutopilot === inv.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Bot className="h-3 w-3" />}
                            autopilot {inv.autoSettle ? "on" : "off"}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7 gap-1 px-2 text-xs text-muted-foreground"
                            onClick={() => copy(`${window.location.origin}/pay/${inv.reference}`, "Client payment link")}
                          >
                            <Link2 className="h-3 w-3" /> share client link
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        <BadgeCheck className="h-3.5 w-3.5 text-primary" /> settled {inv.paidAt ? timeAgo(inv.paidAt) : ""}
                      </span>
                    )}
                  </div>
                </div>
                {latest && (
                  <p className="mt-3 border-t pt-3 text-xs text-muted-foreground">
                    Last payment: {usd(latest.amountInUsd)} from <span className="font-medium text-foreground/80">{latest.sourceChain.toUpperCase()}</span> →{" "}
                    {latest.amountOutUsd ? `${latest.amountOutUsd.toFixed(2)} USDC on NEAR · ` : ""}
                    <StatusBadgeInline status={latest.status} />
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Batch payroll dialog */}
      <Dialog open={batchOpen} onOpenChange={(open) => !open && setBatchOpen(false)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-primary" /> Batch payroll
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="runlabel">Run label</Label>
              <Input
                id="runlabel"
                placeholder="November contractor payroll"
                value={batchLabel}
                onChange={(e) => setBatchLabel(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">Every invoice gets this label as a badge, and one summary event lands in the audit trail.</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="runlines">Freelancers — one per line</Label>
              <Textarea
                id="runlines"
                rows={6}
                placeholder={"Acme Studio, 1450, maria.padala.near\nNorthwind Labs, 900, ben.padala.near"}
                value={batchText}
                onChange={(e) => setBatchText(e.target.value)}
                className="font-mono text-sm"
              />
              <p className="text-xs text-muted-foreground">Paste from a spreadsheet — commas or tabs, up to 50 lines. Empty lines and #comments are ignored.</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="rundue">Scheduled for (optional)</Label>
                <Input id="rundue" type="date" value={batchScheduledFor} onChange={(e) => setBatchScheduledFor(e.target.value)} />
              </div>
              <div className="flex items-end pb-1">
                <p className="text-sm">
                  <span className="text-muted-foreground">Live total: </span>
                  <span className="font-bold tabular-nums text-primary">{usd(batchTotal)}</span>
                  <span className="ml-1 text-xs text-muted-foreground">· {parsed.lines.length} line{parsed.lines.length === 1 ? "" : "s"}</span>
                </p>
              </div>
            </div>
            <div className="rounded-lg border bg-card/60 p-3 space-y-3">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="flex items-center gap-1.5 text-sm font-medium">
                    <Bot className="h-4 w-4 text-primary" /> Autopilot for every line
                  </p>
                  <p className="text-xs text-muted-foreground">The agent settles each invoice on its own when the route fee fits.</p>
                </div>
                <Switch checked={batchAutoSettle} onCheckedChange={setBatchAutoSettle} aria-label="Toggle batch autopilot" />
              </div>
              {batchAutoSettle && (
                <div className="space-y-1.5">
                  <Label htmlFor="runfee" className="text-xs">Max route fee (%)</Label>
                  <Input id="runfee" type="number" min="0.01" max="10" step="0.01" value={batchMaxFeePct} onChange={(e) => setBatchMaxFeePct(e.target.value)} className="h-8" />
                </div>
              )}
            </div>

            {/* Policy pre-flight (live, client-side; the server re-checks) */}
            {preFlight.length > 0 && (
              <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3">
                <p className="flex items-center gap-2 text-sm font-semibold text-amber-400">
                  <CircleAlert className="h-4 w-4" /> Policy pre-flight warning
                </p>
                <ul className="mt-1 space-y-1 text-xs text-amber-300/90">
                  {preFlight.map((w, i) => (
                    <li key={i}>· {w}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Parse errors (client) or per-line validation errors (server) */}
            {(parsed.errors.length > 0 || serverLineErrors.length > 0) && (
              <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-3">
                <p className="text-sm font-semibold text-red-400">Nothing will be created — fix these lines:</p>
                <ul className="mt-1 space-y-1 text-xs text-red-300/90">
                  {parsed.errors.map((e, i) => (
                    <li key={`p${i}`}>· line {e.line}: {e.error}</li>
                  ))}
                  {serverLineErrors.map((e, i) => (
                    <li key={`s${i}`}>· line {e.line}: {e.error}</li>
                  ))}
                </ul>
              </div>
            )}

            <Button onClick={createPayrollRun} disabled={creatingRun || !batchReady} className="w-full font-semibold">
              {creatingRun ? <Loader2 className="h-4 w-4 animate-spin" /> : <Layers className="h-4 w-4" />}
              {creatingRun ? "Creating run…" : `Create run — ${parsed.lines.length} invoice${parsed.lines.length === 1 ? "" : "s"}${parsed.lines.length ? ` · ${usd(batchTotal)}` : ""}`}
            </Button>
            <p className="text-center text-xs text-muted-foreground">All-or-nothing: a typo in line 9 never leaves a half-created payroll. Refund addresses derive per invoice.</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Pay dialog */}
      <Dialog open={!!payInvoice} onOpenChange={(open) => !open && setPayInvoice(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex flex-wrap items-center gap-2">
              Pay {payInvoice?.reference} <span className="text-primary">{usd(payInvoice?.amountUsd ?? 0)}</span>
            </DialogTitle>
          </DialogHeader>
          {payInvoice && (
            <div className="space-y-5">
              {/* Step 1: choose chain */}
              <div className="space-y-2">
                <Label>Fund with USDC from</Label>
                <div className="grid grid-cols-2 gap-2">
                  {chains.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setChainId(c.id)}
                      className={`rounded-lg border p-3 text-left transition-colors ${chainId === c.id ? "border-primary bg-primary/10" : "border-border hover:border-primary/40"}`}
                    >
                      <span className="block text-sm font-semibold">{c.label}</span>
                      <span className="block text-xs text-muted-foreground">{c.note}</span>
                    </button>
                  ))}
                </div>
              </div>

              <Button onClick={payInvoiceAction} disabled={paying} className="w-full font-semibold">
                {paying ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShieldCheck className="h-4 w-4" />}
                {paying ? "Running policy check + quoting…" : "Pay from agent treasury"}
              </Button>

              {/* Blocked */}
              {flow?.error && flow.decision && (
                <div className="rounded-lg border border-red-500/40 bg-red-500/10 p-4">
                  <p className="flex items-center gap-2 font-semibold text-red-400">
                    <CircleAlert className="h-4 w-4" /> {flow.error}
                  </p>
                  <ul className="mt-2 space-y-1 text-sm text-red-300/90">
                    {flow.decision.blockedReasons.map((r, i) => (
                      <li key={i}>· {r}</li>
                    ))}
                  </ul>
                  <p className="mt-2 text-xs text-muted-foreground">Nothing moved. The block attempt is recorded in the audit trail.</p>
                </div>
              )}

              {/* Policy checks */}
              {flow?.decision && (
                <div className="space-y-2">
                  <p className="flex items-center gap-2 text-sm font-semibold">
                    <ShieldCheck className="h-4 w-4 text-primary" /> Policy check —{" "}
                    <Badge variant="outline" className={flow.decision.mode === "AUTO_APPROVED" ? "border-primary/40 text-primary" : flow.decision.mode === "WITHIN_LIMITS" ? "border-amber-500/40 text-amber-400" : "border-red-500/40 text-red-400"}>
                      {flow.decision.mode.replace(/_/g, " ")}
                    </Badge>
                  </p>
                  <div className="space-y-1.5">
                    {flow.decision.checks.map((c) => (
                      <div key={c.name} className="flex items-start gap-2 rounded-md border bg-card/60 p-2 text-sm">
                        {c.passed ? (
                          <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                        ) : (
                          <CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-red-400" />
                        )}
                        <div>
                          <span className="font-medium">{c.label}</span>
                          <span className="block text-xs text-muted-foreground">{c.detail}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quote + deposit */}
              {flow?.quote && flow.payment && (
                <div className="space-y-3">
                  <Separator />
                  <div className="rounded-lg border border-primary/30 bg-primary/5 p-4 space-y-2 text-sm">
                    <p className="flex items-center justify-between">
                      <span className="text-muted-foreground">1Click quote (live)</span>
                      <Badge variant="outline" className="border-primary/40 text-primary">~{flow.quote.timeEstimate}s</Badge>
                    </p>
                    <p className="flex items-center justify-between">
                      <span className="text-muted-foreground">Employer sends</span>
                      <span className="font-semibold">{(Number(flow.quote.amountIn) / 1e6).toLocaleString("en-US", { maximumFractionDigits: 2 })} USDC · {chainId.toUpperCase()}</span>
                    </p>
                    <p className="flex items-center justify-between">
                      <span className="text-muted-foreground">Freelancer receives</span>
                      <span className="font-semibold text-primary">{flow.quote.amountOutFormatted} USDC on NEAR</span>
                    </p>
                    {payInvoice.refundAddress && (
                      <p className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">If the swap fails, refunds go to</span>
                        <button className="flex items-center gap-1 font-mono text-primary/90 hover:underline" onClick={() => copy(payInvoice.refundAddress!, "Refund address")} title={`MPC-derived via "${payInvoice.refundPath}"`}>
                          {shortAddr(payInvoice.refundAddress)} <Copy className="h-3 w-3" />
                        </button>
                      </p>
                    )}
                    <Separator />
                    <div>
                      <p className="text-xs text-muted-foreground">Deposit address (real, from the quote)</p>
                      <button className="mt-1 flex w-full items-center justify-between gap-2 rounded-md border bg-background/60 p-2 text-left font-mono text-xs hover:border-primary/40" onClick={() => copy(flow.quote!.depositAddress, "Deposit address")}>
                        <span className="truncate">{flow.quote.depositAddress}</span>
                        <Copy className="h-3.5 w-3.5 shrink-0" />
                      </button>
                      <p className="mt-1 text-xs text-muted-foreground">
                        Send USDC here on {chainId.toUpperCase()} and solvers settle to {payInvoice.freelancerAccount} automatically. Expires {new Date(flow.quote.deadline).toLocaleTimeString()}.
                      </p>
                    </div>
                  </div>

                  {/* Timeline */}
                  <div className="flex items-center justify-between rounded-lg border p-3">
                    {TIMELINE.map((s, i) => {
                      const currentIdx = TIMELINE.indexOf(flow.payment!.status);
                      const reached = currentIdx >= i && currentIdx !== -1;
                      return (
                        <div key={s} className="flex flex-1 items-center">
                          <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full border text-[10px] font-bold ${reached ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground"}`}>
                            {i + 1}
                          </div>
                          {i < TIMELINE.length - 1 && <div className={`h-px flex-1 ${currentIdx > i ? "bg-primary" : "bg-border"}`} />}
                        </div>
                      );
                    })}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button variant="secondary" size="sm" onClick={() => checkLiveStatus(flow.payment!.id)} disabled={flow.checking}>
                      {flow.checking ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />} Check live status
                    </Button>
                    {flow.payment.status !== "SUCCESS" && (
                      <Button variant="outline" size="sm" onClick={() => simulateSettlement(flow.payment!.id)} disabled={flow.checking} className="border-amber-500/40 text-amber-400 hover:bg-amber-500/10">
                        <Wallet className="h-3.5 w-3.5" /> Simulate settlement (demo)
                      </Button>
                    )}
                  </div>
                  {flow.payment.status === "SUCCESS" && (
                    <p className="flex items-center gap-2 rounded-lg border border-primary/40 bg-primary/10 p-3 text-sm font-medium text-primary">
                      <BadgeCheck className="h-4 w-4" /> Settled — {flow.payment.amountOutUsd?.toFixed(2) ?? usd(flow.payment.amountInUsd)} USDC credited to {payInvoice.freelancerAccount}{flow.payment.simulated ? " (demo settlement)" : " via NEAR Intents"}.
                    </p>
                  )}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function StatusBadgeInline({ status }: { status: string }) {
  const ok = status === "SUCCESS";
  return <span className={ok ? "font-medium text-primary" : "font-medium text-amber-400"}>{status.replace(/_/g, " ").toLowerCase()}</span>;
}
