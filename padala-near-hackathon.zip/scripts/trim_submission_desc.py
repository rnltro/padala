#!/usr/bin/env python3
"""Trim the section-3 form description in padala-submission-copy.md to leave
headroom for the real repo URL, then verify the final character count."""
import re

PATH = "/home/z/my-project/download/padala-submission-copy.md"
text = open(PATH, encoding="utf-8").read()

NEW_DESC = """What does it take for a freelancer in Manila to get paid from a client in London — without losing days and $25–50 to rails built in the 1970s?

Padala is a cross-chain payroll agent on NEAR that answers with working code:

• Cross-chain settlement — invoices quote real routes through NEAR Intents (1Click). The client pays USDC on Base, Ethereum, Arbitrum or Solana into a real per-swap deposit address; the freelancer receives native USDC on NEAR within the quote's own time estimate. Deposit actual USDC and the invoice settles for real.

• An agent that constrains itself — every payment passes a 6-check spending policy (per-tx limit, daily cap, chain and payee allowlists, treasury balance) before a deposit address is ever issued. Autopilot re-quotes every 2 minutes and settles only when the live fee fits your budget — over budget it skips and logs why. Nothing moves outside policy, human or autonomous.

• Chain Signatures refunds — a failed swap refunds to a per-invoice address derived from the NEAR MPC root key; the private key never exists anywhere. A pinned test vector proves the derivation matches the live contract.

• Real payroll ops — batch payroll for up to 50 freelancers (all-or-nothing, policy pre-flight), CSV ledger export, a public no-login payment link with QR, and an append-only audit trail.

Try it: create an invoice, watch the policy pass, pay from Base, settle — then try an over-limit payment and watch it BLOCKED, nothing moved.

Everything runs from a cold clone with two commands — bun install, bun run setup — no sign-up, no keys, no faucet — pinned by 30 unit tests and a 21-step smoke test. Honest gaps (Solana refund derivation, TEE-hosted policy engine) are in the README's roadmap, not hidden.

Padala means "to send" in Tagalog. The Philippines receives ~$40B/yr in remittances — this is what receiving them should feel like.

Repo: <REPO_URL>"""

m = re.search(r'(## 3\..*?```\n)(.*?)(```)', text, re.S)
old = m.group(2)
assert old.startswith("What does it take"), "unexpected block content"
text = text.replace(m.group(2), NEW_DESC + "\n")

# refresh the "two things before submitting" note with the real headroom math
url_len = len("https://github.com/your-handle/padala")
total = len(NEW_DESC.replace("<REPO_URL>", "x" * url_len))
text = re.sub(
    r"Paste as-is \(character count verified below\)\..*?\n\n",
    f"Paste as-is. Count with a real repo URL substituted: **{total} / 2,000 chars** "
    f"(placeholder → e.g. https://github.com/your-handle/padala, {url_len} chars — "
    f"headroom left even for a longer URL). Before submitting:\n"
    f"1. Replace `<REPO_URL>` with the public GitHub link and re-check the count.\n"
    f"2. OPTIONAL (only if the real settlement happened): insert after the first bullet — "
    f"\"We executed a live mainnet settlement: $10 USDC deposited on Base, received on NEAR "
    f"in ~XX seconds.\" and re-check the count.\n\n",
    text,
    count=1,
    flags=re.S,
)

open(PATH, "w", encoding="utf-8").write(text)

# verification
m2 = re.search(r'## 3\..*?```\n(.*?)```', text, re.S)
desc = m2.group(1).rstrip("\n")
print(f"placeholder version: {len(desc)} chars (limit 2000)")
print(f"with realistic URL:  {len(desc.replace('<REPO_URL>', 'https://github.com/your-handle/padala'))} chars")
print(f"starts with question: {desc.startswith('What does it take')}")
print(f"still 20+ chars and under 2000 with a 60-char URL: {len(desc.replace('<REPO_URL>', 'x'*60)) <= 2000}")
