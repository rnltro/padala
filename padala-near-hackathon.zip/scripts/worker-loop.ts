/**
 * Local Autopilot loop — the "autonomous payments" scheduler, zero deps.
 *
 * Hits GET /api/cron/settle every WORKER_INTERVAL_MS while the Next.js dev
 * server runs. Every pass asks the agent to settle open Autopilot invoices;
 * the agent re-quotes 1Click, compares the fee against each invoice's budget
 * and either executes or skips — every decision lands in the audit trail.
 *
 * Cross-platform (bun runs TS natively on Windows/macOS/Linux):
 *   bun run worker                      # defaults below
 *   SETTLE_URL=... CRON_SECRET=... bun run worker
 */

const SETTLE_URL = process.env.SETTLE_URL || "http://localhost:3000/api/cron/settle";
const INTERVAL_MS = Number(process.env.WORKER_INTERVAL_MS || 120_000); // 2 min
const CRON_SECRET = process.env.CRON_SECRET;

export {}; // make this a module so top-level await is valid TS

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function tick(): Promise<void> {
  const ts = new Date().toISOString().slice(11, 19);
  try {
    const res = await fetch(SETTLE_URL, {
      headers: CRON_SECRET ? { Authorization: `Bearer ${CRON_SECRET}` } : {},
      signal: AbortSignal.timeout(60_000),
    });
    const body = (await res.json()) as {
      checked?: number;
      executed?: number;
      skipped?: number;
      results?: Array<{ reference: string; action: string; feeBps?: number; budgetBps?: number; reason?: string }>;
      error?: string;
    };
    if (!res.ok) {
      console.error(`[${ts}] tick failed: HTTP ${res.status} ${body.error ?? ""}`);
      return;
    }
    console.log(`[${ts}] checked=${body.checked} executed=${body.executed} skipped=${body.skipped}`);
    for (const r of body.results ?? []) {
      const fee = r.feeBps != null ? ` fee=${r.feeBps}bps budget=${r.budgetBps}bps` : "";
      const why = r.reason ? ` (${r.reason})` : "";
      console.log(`  ${r.reference}: ${r.action}${fee}${why}`);
    }
  } catch (err) {
    console.error(`[${ts}] tick error: ${err instanceof Error ? err.message : err}`);
  }
}

console.log(`Padala Autopilot worker → ${SETTLE_URL} every ${INTERVAL_MS / 1000}s (Ctrl+C to stop)`);
// Fire immediately, then keep looping.
for (;;) {
  await tick();
  await sleep(INTERVAL_MS);
}
