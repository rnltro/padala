import { PrismaClient } from "@prisma/client";
import { resetDemoData } from "../src/lib/reset";

/** Reset the demo DB back to the pristine seed state (2 invoices, audit history). */
const db = new PrismaClient();

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

async function main() {
  const { cleared } = await resetDemoData(db);
  console.log(
    `demo data cleared (${cleared.invoices} invoices, ${cleared.payments} payments, ${cleared.auditEvents} audit events, ${cleared.payrollRuns} payroll runs) — pristine seed restored`,
  );
}
