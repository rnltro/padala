/**
 * Offline verification of Padala's Chain-Signatures refund derivation.
 *
 * Pins the local KDF to a vector captured from the LIVE near/mpc testnet
 * contract (v1.signer-prod.testnet) — the same vector used by
 * NearDeFi/chainsig.js in __tests__/contracts/derivation.test.ts.
 * If near/mpc ever changes its derivation scheme, this test fails loudly
 * instead of silently deriving addresses the contract would not control.
 *
 * Run: bun scripts/verify-derivation.ts
 */

import { deriveChildSec1PublicKey, evmAddressFromSec1 } from "../src/lib/chainsignatures";
import { base58 } from "@scure/base";

// Root key of v1.signer-prod.testnet (pinned 2026-11-09 so this runs offline).
const TESTNET_ROOT_NAJ =
  "secp256k1:4NfTiv3UsGahebgTaHyD9vF8KYKMBnfd6kh94mK6xv8fGBiJB8TBtFMP5WWXz6B89Ac1fbpzPwAvoyQebemHFwx3";
// Captured contract output for predecessor "derivation-test.testnet", path "unit-test".
const EXPECTED_CHILD_NAJ =
  "secp256k1:3b3GS4kaAPvzxFUEYKiMvXeuBzttMZosggT3iAAbyZzAfQc1Dn4eLrDshNGGeKZyfSK7xegjPSq553NXHisMLiyA";

const rootSec1 = "04" + Buffer.from(base58.decode(TESTNET_ROOT_NAJ.split(":")[1])).toString("hex");
const expectedSec1 = "04" + Buffer.from(base58.decode(EXPECTED_CHILD_NAJ.split(":")[1])).toString("hex");

const child = deriveChildSec1PublicKey(rootSec1, "derivation-test.testnet", "unit-test");

console.log("derived :", "secp256k1:" + base58.encode(Buffer.from(child.slice(2), "hex")));
console.log("expected:", EXPECTED_CHILD_NAJ);

if (child !== expectedSec1) {
  console.error("FAIL — local KDF drifted from the live contract output");
  process.exit(1);
}

// Shape check: an EVM address derived from the live MAINNET root key must be
// a valid checksummed 20-byte address. (Mainnet key rotates with the MPC
// network, so we only assert the format here, not a pinned value.)
const MAINNET_ROOT_NAJ =
  "secp256k1:3tFRbMqmoa6AAALMrEFAYCEoHcqKxeW38YptwowBVBtXK1vo36HDbUWuR6EZmoK4JcH6HDkNMGGqP1ouV7VZUWya";
const mainnetSec1 = "04" + Buffer.from(base58.decode(MAINNET_ROOT_NAJ.split(":")[1])).toString("hex");
const mainnetChild = deriveChildSec1PublicKey(mainnetSec1, "agent.padala.near", "refund-INV-1042");
const address = evmAddressFromSec1(mainnetChild);

if (!/^0x[0-9a-fA-F]{40}$/.test(address)) {
  console.error("FAIL — derived EVM address malformed:", address);
  process.exit(1);
}

console.log("sample mainnet refund address for agent.padala.near / refund-INV-1042:", address);
console.log("PASS — derivation matches the live contract output");
