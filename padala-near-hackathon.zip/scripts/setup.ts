/**
 * `bun run setup` — idempotent first-run bootstrap for Padala.
 *
 * Safe to run any number of times (before or after the dev server started):
 *   1. creates the ./db directory,
 *   2. writes .env if missing (never overwrites one you edited),
 *   3. generates the Prisma client,
 *   4. creates the SQLite tables (`prisma db push`),
 *   5. verifies the database is reachable and readable.
 *
 * It does NOT seed data — the dashboard seeds itself on first load
 * (see ensureSeed in src/lib/treasury.ts), so a fresh clone boots
 * with a story on screen, not an empty table.
 *
 * After this, `bun run dev` → http://localhost:3000 — no other steps.
 */

import { spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const DB_DIR = join(ROOT, "db");
const ENV_PATH = join(ROOT, ".env");

function step(label: string) {
  console.log(`\n▸ ${label}`);
}

function run(cmd: string[], label: string, env: NodeJS.ProcessEnv): void {
  const res = spawnSync(cmd[0], cmd.slice(1), {
    cwd: ROOT,
    env,
    stdio: ["ignore", "pipe", "pipe"],
    encoding: "utf8",
  });
  if (res.status !== 0) {
    console.error(`\n✗ ${label} failed.`);
    if (res.stdout?.trim()) console.error(res.stdout.trim().split("\n").slice(-15).join("\n"));
    if (res.stderr?.trim()) console.error(res.stderr.trim().split("\n").slice(-15).join("\n"));
    process.exit(1);
  }
  console.log(`  ✓ ${label}`);
}

function main() {
  console.log("Padala setup — .env + Prisma client + SQLite tables (idempotent)");

  // 1. db directory (SQLite refuses to create the folder itself).
  step("creating ./db directory");
  if (!existsSync(DB_DIR)) {
    mkdirSync(DB_DIR, { recursive: true });
    console.log("  ✓ db/ created");
  } else {
    console.log("  ✓ already exists");
  }

  // 2. .env — only when missing, so local edits survive re-runs.
  step("writing .env");
  if (existsSync(ENV_PATH)) {
    console.log("  ✓ .env already exists — kept as-is (delete it to regenerate)");
  } else {
    // Absolute path: Prisma resolves relative SQLite paths against the
    // schema folder, which surprises people — absolute avoids the trap
    // and works no matter which directory the server is started from.
    const env = [
      `DATABASE_URL=file:${join(DB_DIR, "padala.db")}`,
      "",
      "# NEAR account that requests Chain-Signatures derivations (the Padala agent).",
      "# Becomes part of every derived refund address.",
      "PADALA_SIGNER_ID=agent.padala.near",
      "",
      "# ---- Optional overrides (defaults work out of the box) ----",
      "# NEAR RPC used to read the MPC root key (cached 1h):",
      "# NEAR_RPC_URL=https://rpc.mainnet.near.org",
      "# Chain Signatures MPC contract (testnet equivalent: v1.signer-testnet):",
      "# CHAIN_SIGNATURES_CONTRACT=v1.signer",
      "# Pin the MPC root key to run derivation fully offline:",
      "# MPC_PUBLIC_KEY=secp256k1:...",
      "# If set, POST /api/cron/settle and POST /api/demo/reset require:",
      "#   Authorization: Bearer <secret>",
      "# CRON_SECRET=",
      "",
    ].join("\n");
    writeFileSync(ENV_PATH, env);
    console.log("  ✓ .env written (DATABASE_URL → db/padala.db, agent.padala.near)");
  }

  // Read the effective DATABASE_URL from .env (setup guarantees it exists now)
  // and FORCE it into the Prisma child processes. Reason: a pre-existing
  // DATABASE_URL in the caller's shell (CI, containers) would otherwise win —
  // dotenv never overrides real env vars — and `db push` would silently
  // provision a different database than the one the app will use.
  const envText = readFileSync(ENV_PATH, "utf8");
  const dbUrlRaw = envText.match(/^DATABASE_URL=(.+)$/m)?.[1]?.trim() ?? `file:${join(DB_DIR, "padala.db")}`;
  const dbFilePath = dbUrlRaw.startsWith("file:") ? dbUrlRaw.slice(5) : dbUrlRaw;
  const dbFileAbsolute = dbFilePath.startsWith("/") ? dbFilePath : resolve(ROOT, dbFilePath);
  const prismaEnv = { ...process.env, DATABASE_URL: `file:${dbFileAbsolute}` };

  // 3. Prisma client (postinstall normally does this; re-run to be sure).
  step("generating Prisma client");
  run(["bun", "run", "db:generate"], "prisma generate", prismaEnv);

  // 4. Tables.
  step("creating SQLite tables");
  run(["bun", "run", "db:push"], "prisma db push", prismaEnv);

  // 5. Verify — the SAME file the prisma commands were pointed at.
  step("verifying database");
  if (!existsSync(dbFileAbsolute) || statSync(dbFileAbsolute).size === 0) {
    console.error(`\n✗ Database file not found at ${dbFileAbsolute} — re-run \`bun run setup\`.`);
    process.exit(1);
  }
  console.log(`  ✓ ${dbFileAbsolute} exists and is non-empty`);

  console.log(`
✅ Setup complete.

  bun run dev        → http://localhost:3000   (dashboard, seeds itself on first load)
  bun run worker     → Autopilot loop (optional, 2-min ticks)
  bun test           → policy engine unit tests
  bun scripts/smoke.ts → end-to-end API smoke test (server must be running)

If anything looks broken later, open http://localhost:3000/api/health —
it names the exact cause and the fix.`);
}

main();
