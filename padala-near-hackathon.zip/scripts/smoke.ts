/**
 * End-to-end API smoke test — `bun scripts/smoke.ts` (server must be running).
 *
 * Walks the exact demo path a judge would click, against BASE_URL
 * (default http://localhost:3000):
 *   health → chains → invoices(seed) → create → pay (live 1Click quote)
 *   → simulate settlement → live status → batch payroll run → CSV export
 *   → audit trail → treasury/stats/policy → demo reset (pristine seed).
 *
 * Leaves the DB in the pristine seeded state when it finishes.
 * Set CRON_SECRET (env) if the server requires it for /api/demo/reset.
 */

const BASE = (process.argv[2] ?? process.env.BASE_URL ?? "http://localhost:3000").replace(/\/$/, "");
const SECRET = process.env.CRON_SECRET ?? process.env.SMOKE_SECRET ?? "";

let failures = 0;
function ok(label: string, cond: boolean, extra = "") {
  console.log(`${cond ? "  ✓" : "  ✗ FAIL"} ${label}${extra ? ` — ${extra}` : ""}`);
  if (!cond) failures += 1;
}

async function j(path: string, init?: RequestInit): Promise<{ status: number; body: any }> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (SECRET && path.startsWith("/api/demo/reset")) headers.Authorization = `Bearer ${SECRET}`;
  const res = await fetch(`${BASE}${path}`, { ...init, headers });
  const text = await res.text();
  let body: any = text;
  try {
    body = JSON.parse(text);
  } catch {
    /* CSV or other text */
  }
  return { status: res.status, body };
}

async function main() {
  console.log(`Padala smoke test → ${BASE}\n`);

  // 1. Health
  const health = await j("/api/health");
  ok("health ok:true + diagnosis", health.status === 200 && health.body.ok === true, health.body.diagnosis ?? "");

  // 2. Chains
  const chains = await j("/api/chains");
  ok("chains (Base/ETH/Arbitrum/Solana)", chains.status === 200 && (chains.body.chains?.length ?? 0) >= 3, `${chains.body.chains?.length ?? 0} chains`);

  // 3. Invoice list (seeds itself on first call)
  const list0 = await j("/api/invoices");
  const seeded = list0.body.invoices ?? [];
  ok("invoice list seeds INV-1001 PAID + INV-1002 awaiting", seeded.length >= 2 && seeded.some((i: any) => i.reference === "INV-1001" && i.status === "PAID") && seeded.some((i: any) => i.reference === "INV-1002"), `${seeded.length} invoices`);

  // 4. Create an invoice (derives MPC refund address via live NEAR RPC)
  const created = await j("/api/invoices", {
    method: "POST",
    body: JSON.stringify({
      clientName: "Smoke Test Co",
      description: "smoke-test invoice",
      amountUsd: 321,
      dueDate: new Date(Date.now() + 7 * 864e5).toISOString(),
      freelancerAccount: "maria.padala.near",
    }),
  });
  const inv = created.body.invoice;
  ok("create invoice → 201 + reference", created.status === 201 && !!inv?.reference, inv?.reference);
  ok("refund address derived (Chain Signatures)", !!inv?.refundAddress && String(inv.refundAddress).startsWith("0x"), inv?.refundAddress ? "yes" : "fallback (offline?)");
  if (inv && !String(inv.refundAddress ?? "").startsWith("0x")) {
    console.log("  ⚠ derivation fell back — NEAR RPC unreachable from this machine; /api/health → network.nearRpc names the error\n");
  }

  // 5. Pay from agent — policy gate + live 1Click quote
  const pay = await j(`/api/invoices/${inv.id}/pay`, { method: "POST", body: JSON.stringify({ chainId: "base" }) });
  const payment = pay.body.payment;
  const checks = pay.body.decision?.checks;
  ok(
    "pay → policy decision (allowed)",
    pay.status === 201 && pay.body.decision?.allowed === true,
    checks ? `${checks.filter((c: any) => c.passed).length}/6 checks` : (pay.body.error ?? `HTTP ${pay.status}`),
  );
  ok(
    "pay → live 1Click quote + real deposit address",
    !!payment?.depositAddress && !!pay.body.quote?.timeEstimate,
    payment ? `~${pay.body.quote?.timeEstimate ?? "?"}s, deposit ${payment.depositAddress.slice(0, 10)}…` : (pay.body.error ?? "no payment returned"),
  );
  if (!payment) {
    // The pay route refused to quote (policy block, unreachable 1Click API, …).
    // Everything below that needs a payment is skipped; the rest still runs so
    // the DB ends in the pristine state either way. /api/health's `network`
    // section names the unreachable API when this is a connectivity problem.
    console.log("\n  ⚠ skipping the settlement walk (simulate + status) — no payment was created");
    console.log("  ⚠ open http://localhost:3000/api/health → `network` section names the cause\n");
  } else {
    // 6. Simulate settlement (demo)
    const sim = await j(`/api/payments/${payment.id}/simulate`, { method: "POST" });
    ok("simulate settlement → SUCCESS", sim.status === 200 && sim.body.payment?.status === "SUCCESS");

    // 7. Live status poll (1Click)
    const status = await j(`/api/payments/${payment.id}/status`);
    ok("payment status endpoint", status.status === 200 && !!status.body.payment?.status, status.body.payment?.status ?? "");
  }

  // 8. Batch payroll — 3 lines, one intentionally bad → all-or-nothing 400
  const badBatch = await j("/api/payroll-runs", {
    method: "POST",
    body: JSON.stringify({
      label: "Smoke bad run",
      lines: [
        { clientName: "Good Co", amountUsd: 100, freelancerAccount: "maria.padala.near" },
        { clientName: "Typo Co", amountUsd: 200, freelancerAccount: "not-an-account" },
      ],
    }),
  });
  ok(
    "batch all-or-nothing: bad line → 400 + per-line errors",
    badBatch.status === 400 && (badBatch.body.lineErrors?.length ?? 0) === 1,
    badBatch.body.error ?? "",
  );
  const listAfterBad = await j("/api/invoices");
  ok("…and nothing was created", (listAfterBad.body.invoices ?? []).every((i: any) => i.clientName !== "Good Co"));

  // 9. Batch payroll — valid 3-line run
  const batch = await j("/api/payroll-runs", {
    method: "POST",
    body: JSON.stringify({
      label: "Smoke batch",
      lines: [
        { clientName: "Ana Reyes", amountUsd: 850, freelancerAccount: "ana.padala.near" },
        { clientName: "Ben Santos", amountUsd: 1200, freelancerAccount: "ben.padala.near" },
        { clientName: "Cara Ding", amountUsd: 430, freelancerAccount: "cara.padala.near" },
      ],
    }),
  });
  ok(
    "batch payroll run → 201, 3 invoices, run total",
    batch.status === 201 && batch.body.run?.lineCount === 3 && Math.abs((batch.body.run?.totalUsd ?? 0) - 2480) < 0.01,
    `${batch.body.run?.lineCount ?? 0} lines · $${batch.body.run?.totalUsd ?? 0}`,
  );
  ok(
    "batch invoices carry the run label + MPC refund addresses",
    (batch.body.invoices ?? []).every((i: any) => i.payrollRunLabel === "Smoke batch") &&
      (batch.body.invoices ?? []).every((i: any) => !!i.refundAddress),
  );

  // 10. CSV export (byte-level: res.text() would strip the BOM)
  const csvRes = await fetch(`${BASE}/api/invoices/export`);
  const csvBytes = new Uint8Array(await csvRes.arrayBuffer());
  const csvText = new TextDecoder("utf-8").decode(csvBytes);
  const hasBom = csvBytes[0] === 0xef && csvBytes[1] === 0xbb && csvBytes[2] === 0xbf;
  ok(
    "CSV export: 200 + UTF-8 BOM bytes + CRLF + headers + rows",
    csvRes.status === 200 &&
      hasBom &&
      csvText.includes("\r\n") &&
      csvText.includes("Reference,Client,Status") &&
      csvText.split("\r\n").length > 4,
    `${csvText.split("\r\n").length - 2} data rows`,
  );

  // 11. Audit trail — batch summary event present exactly once
  const audit = await j("/api/audit?limit=300");
  const payrollEvents = (audit.body.events ?? []).filter((e: any) => e.type === "PAYROLL_RUN_CREATED");
  ok("audit: one summary PAYROLL_RUN_CREATED for the whole run", payrollEvents.length === 1, `${payrollEvents.length} events`);
  ok("audit: CSV_EXPORTED recorded", (audit.body.events ?? []).some((e: any) => e.type === "CSV_EXPORTED"));

  // 12. Treasury / stats / policy
  const treasury = await j("/api/treasury");
  ok("treasury stats", treasury.status === 200 && (treasury.body.balanceUsdc ?? 0) > 0);
  const stats = await j("/api/stats");
  ok("impact analytics", stats.status === 200 && stats.body.paymentsSettled >= 2);
  const policy = await j("/api/policy");
  ok("policy readable", policy.status === 200 && (policy.body.policy?.perTxLimitUsd ?? 0) > 0);

  // 13. Reset — pristine seed again (also proves the reset endpoint works)
  const reset = await j("/api/demo/reset", { method: "POST" });
  ok("demo reset → ok:true", reset.status === 200 && reset.body.ok === true, JSON.stringify(reset.body.cleared ?? {}));
  const listFinal = await j("/api/invoices");
  ok("post-reset dashboard is pristine", (listFinal.body.invoices ?? []).length === 2);

  console.log(`\n${failures === 0 ? "✅ ALL PASS" : `❌ ${failures} FAILURES`}`);
  process.exit(failures === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error("smoke test crashed:", e);
  process.exit(1);
});
